# Changelog

## 1.1.0

### Fixed
- **Web UI never used the vault.** `main.tsx` was a mock: any password "unlocked", items lived in memory, nothing was encrypted or persisted. The UI now runs on `VaultService` (IndexedDB, AES-GCM-256, PBKDF2-SHA256 600k).
- **Core crashed on import.** `sanitizeFilename` used the regex range `|-\u001f` (out of order), a SyntaxError that took down all of `@pv/core`.
- **Blank WebView on Android.** Vite built absolute `/assets/...` URLs and CI copied files to `assets/assets/`, while the app loaded `/assets/index.html`. Now: `base: './'`, output goes to `assets/web/`, and the app loads `/assets/web/index.html`.
- **`npm run android:sync` pointed to a script that did not exist.** Added `scripts/sync-android-assets.mjs`, which also fails the build if index.html references missing, absolute or remote files.
- **CI broke without a lockfile.** `npm ci` and `cache: npm` need `package-lock.json`, and the repo has none. CI now falls back to `npm install`.
- **`npm run test:node` failed on Node 22** (`node --test <dir>/`). It now uses a glob.
- **Restore could not work on a new device.** It needed an unlocked vault with the same DEK. Added `VaultService.restoreBackupFile(bytes, password)`: it unlocks the backup keyring, verifies every envelope, then does one atomic replace.
- **File picker did nothing on Android** (no `onShowFileChooser`). Implemented it with multi-select support.
- **Backups and attachments could not be saved on Android** (WebView cannot download `blob:` URLs). Added a `PVAndroid.saveFile` bridge that uses the system "Save as" dialog.
- **Background lock ran while a picker was open**, so the picked file was lost. Added a guard that only covers pickers the app opened itself.
- **Activity recreation** (dark-mode switch, keyboard, font scale) reloaded the WebView and dropped the session. Added `configChanges` and state saving.
- Android resources: invalid theme parent reference, API-27 attribute in base `values`, `fontFamily="sans"`, no launcher icon.
- Unused `appcompat` dependency removed. AGP 8.5.2 (which does not officially support SDK 35) was bumped to 8.7.3 with Gradle 8.10.2.

### Security (tightened, nothing weakened)
- Strict CSP in production HTML (no remote origins).
- `FLAG_SECURE`, Android cloud backup and device transfer disabled, external links open outside the WebView, WebView debugging only in debug builds.
- The crypto parameters are unchanged: AES-GCM-256 with 96-bit IV and AAD, PBKDF2-SHA256 with 600,000 iterations and a 16-byte salt, and a non-extractable KEK/DEK hierarchy.

### UI
- New RTL, mobile-first UI: bottom tab bar on phones, sidebar at 1024px and wider. Light, dark and system themes.
- Setup and lock screens with a password-strength meter, and restore from backup on the lock screen.
- Item editor sheet with types, tags, category, URL, custom secret fields (masked, copied with clipboard auto-clear), encrypted attachments with image preview, duplicate, trash, restore and delete forever.
- Search with Persian normalization, type filters, sorting, favorites and trash.
- Settings for theme, auto-lock, lock on background, clipboard clear, previews, change password, backup and restore.
- Toasts, confirm sheets, reduced-motion support and 44px touch targets.
