/**
 * Crypto errors are intentionally coarse: they never echo secrets, key
 * material, or which byte failed. The UI maps codes to human copy.
 */
export type CryptoErrorCode =
  | 'WRONG_PASSWORD'
  | 'DATA_TAMPERED'
  | 'UNSUPPORTED_KDF'
  | 'UNSUPPORTED_CIPHER'
  | 'WEAK_PASSWORD'
  | 'LOCKED';

export class VaultCryptoError extends Error {
  readonly code: CryptoErrorCode;
  constructor(code: CryptoErrorCode, message?: string) {
    super(message ?? code);
    this.name = 'VaultCryptoError';
    this.code = code;
  }
}
