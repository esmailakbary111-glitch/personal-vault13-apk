import { subtle } from './subtle.ts';
import { toHex, utf8Encode } from './bytes.ts';

export async function sha256(data: Uint8Array): Promise<Uint8Array> {
  return new Uint8Array(await subtle().digest('SHA-256', data));
}

export async function sha256Hex(data: Uint8Array): Promise<string> {
  return toHex(await sha256(data));
}

export async function sha256HexOfString(value: string): Promise<string> {
  return sha256Hex(utf8Encode(value));
}
