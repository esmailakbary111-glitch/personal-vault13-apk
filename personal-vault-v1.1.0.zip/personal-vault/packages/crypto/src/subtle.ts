/**
 * Single access point to the platform Web Crypto implementation.
 * Keeping it isolated makes the crypto package testable in Node, browsers,
 * extension service workers and Android WebView without branching elsewhere.
 */
export function getCrypto(): Crypto {
  const c = globalThis.crypto;
  if (!c || !c.subtle) {
    throw new Error('WebCryptoUnavailable: this runtime does not expose crypto.subtle');
  }
  return c;
}

export function subtle(): SubtleCrypto {
  return getCrypto().subtle;
}
