import { getCrypto } from './subtle.ts';

export function randomBytes(length: number): Uint8Array {
  if (length <= 0) throw new RangeError('randomBytes: length must be positive');
  const out = new Uint8Array(length);
  getCrypto().getRandomValues(out);
  return out;
}

/** RFC 4122 v4 identifier built from CSPRNG bytes (no external dependency). */
export function randomId(): string {
  const b = randomBytes(16);
  b[6] = ((b[6] as number) & 0x0f) | 0x40;
  b[8] = ((b[8] as number) & 0x3f) | 0x80;
  const hex: string[] = [];
  for (const byte of b) hex.push(byte.toString(16).padStart(2, '0'));
  return (
    hex.slice(0, 4).join('') +
    '-' + hex.slice(4, 6).join('') +
    '-' + hex.slice(6, 8).join('') +
    '-' + hex.slice(8, 10).join('') +
    '-' + hex.slice(10, 16).join('')
  );
}
