export type PreviewKind = 'image' | 'pdf' | 'text' | 'audio' | 'video' | 'archive' | 'generic';

const TEXT_EXT = ['txt', 'md', 'csv', 'json', 'log', 'yml', 'yaml', 'xml', 'ini', 'srt'];
const ARCHIVE_EXT = ['zip', 'rar', '7z', 'tar', 'gz'];

export function extensionOf(name: string): string {
  const at = name.lastIndexOf('.');
  return at > 0 && at < name.length - 1 ? name.slice(at + 1).toLowerCase() : '';
}

/**
 * Decides how the UI renders an attachment. The image lightbox is used ONLY
 * for `image`; every other kind gets a file card or a dedicated preview.
 */
export function previewKindOf(mime: string, name: string): PreviewKind {
  const type = (mime || '').toLowerCase();
  const ext = extensionOf(name);
  if (type.startsWith('image/') && !type.includes('svg')) return 'image';
  if (type === 'application/pdf' || ext === 'pdf') return 'pdf';
  if (type.startsWith('text/') || TEXT_EXT.includes(ext)) return 'text';
  if (type.startsWith('audio/')) return 'audio';
  if (type.startsWith('video/')) return 'video';
  if (ARCHIVE_EXT.includes(ext)) return 'archive';
  return 'generic';
}

/** Keeps the original filename and extension intact on export/download. */
export function sanitizeFilename(name: string, fallback = 'file'): string {
  const base = (name || '').replace(/[\\/:*?"<>|\x00-\x1f]/g, '_').replace(/^\.+/, '').trim();
  if (!base) return fallback;
  return base.slice(0, 180);
}

export function formatBytes(size: number, locale = 'fa-IR'): string {
  if (!Number.isFinite(size) || size < 0) return '-';
  const units = ['B', 'KB', 'MB', 'GB'];
  let value = size;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  const digits = value < 10 && unit > 0 ? 1 : 0;
  return `${value.toLocaleString(locale, { maximumFractionDigits: digits })} ${units[unit]}`;
}
