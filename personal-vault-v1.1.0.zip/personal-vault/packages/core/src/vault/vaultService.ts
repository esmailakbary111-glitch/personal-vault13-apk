import {
  createKeyring,
  changePassword as rewrapKeyring,
  decryptBytes,
  decryptJson,
  encryptBytes,
  encryptJson,
  randomId,
  unlockKeyring,
  VaultCryptoError,
  type Envelope,
  type Keyring,
} from '@pv/crypto';
import { VaultError } from '../domain/errors.ts';
import {
  DEFAULT_SETTINGS,
  type AttachmentMeta,
  type ItemContent,
  type ItemDraft,
  type ItemIndexEntry,
  type ItemSummary,
  type Settings,
  type VaultItem,
  type VaultStatus,
} from '../domain/types.ts';
import { LIMITS, buildPreview, normalizeDraft } from '../domain/validation.ts';
import type { AttachmentRef, BlobChunkRecord, ItemRecord, VaultMetaRecord } from '../storage/schema.ts';
import { DB_VERSION, META_KEY } from '../storage/schema.ts';
import type { VaultStore } from '../storage/repositories.ts';
import { SearchIndex, type SearchQuery } from '../search/searchIndex.ts';
import { sanitizeFilename } from '../files/fileTypes.ts';
import { createBackup, validateBackup, verifyBackupEnvelopes } from '../backup/backup.ts';
import type { Session } from './session.ts';

export const CHUNK_BYTES = 256 * 1024;

export interface NewFileInput {
  readonly name: string;
  readonly mime: string;
  readonly bytes: Uint8Array;
}

export interface VaultServiceOptions {
  readonly appVersion: string;
  readonly now?: () => number;
}

function indexAad(id: string): string {
  return `pv.item.${id}.index.v1`;
}
function contentAad(id: string): string {
  return `pv.item.${id}.content.v1`;
}
function chunkAad(blobId: string, chunk: number): string {
  return `pv.blob.${blobId}.${chunk}.v1`;
}

/**
 * Application/domain layer. Owns the rules of the vault; delegates bytes to
 * @pv/crypto and persistence to VaultStore. No UI concepts appear here.
 */
export class VaultService {
  private summaries = new Map<string, ItemSummary>();
  private readonly index = new SearchIndex();
  private settings: Settings = DEFAULT_SETTINGS;
  private keyring: Keyring | null = null;
  private meta: VaultMetaRecord | null = null;
  private readonly now: () => number;

  constructor(
    private readonly store: VaultStore,
    private readonly session: Session,
    private readonly options: VaultServiceOptions,
  ) {
    this.now = options.now ?? (() => Date.now());
    this.session.subscribe((event) => {
      if (!event.unlocked) this.forgetPlaintext();
    });
  }

  // ---- lifecycle --------------------------------------------------------
  async load(): Promise<VaultStatus> {
    this.meta = (await this.store.readMeta()) ?? null;
    this.keyring = this.meta?.keyring ?? null;
    const persisted = await this.store.readSettings();
    this.settings = { ...DEFAULT_SETTINGS, ...(persisted as Partial<Settings>) };
    this.session.configure(this.settings);
    return this.status();
  }

  status(): VaultStatus {
    const trashCount = [...this.summaries.values()].filter((s) => s.deletedAt !== null).length;
    return {
      exists: this.keyring !== null,
      unlocked: this.session.isUnlocked,
      itemCount: this.summaries.size - trashCount,
      trashCount,
      lastUnlockAt: this.session.unlockedSince,
      createdAt: this.meta?.createdAt ?? null,
    };
  }

  getSettings(): Settings {
    return this.settings;
  }

  /** Settings are deliberately non-sensitive, so they stay readable while locked. */
  async updateSettings(patch: Partial<Settings>): Promise<Settings> {
    this.settings = { ...this.settings, ...patch };
    await this.store.writeSettings({ ...patch });
    this.session.configure(this.settings);
    return this.settings;
  }

  async createVault(password: string): Promise<void> {
    if (this.keyring) throw new VaultError('VAULT_EXISTS');
    let created;
    try {
      created = await createKeyring(password);
    } catch (error) {
      throw this.mapCryptoError(error);
    }
    const timestamp = this.now();
    const meta: VaultMetaRecord = {
      key: META_KEY,
      schemaVersion: DB_VERSION,
      appVersion: this.options.appVersion,
      keyring: created.keyring,
      createdAt: timestamp,
      updatedAt: timestamp,
    };
    await this.store.writeMeta(meta);
    this.meta = meta;
    this.keyring = created.keyring;
    this.session.open(created.dek);
    this.summaries.clear();
    this.index.clear();
  }

  /**
   * Unlock decrypts only the lightweight index envelopes (title/type/tags/
   * preview). Bodies and files stay encrypted until the user opens them, so
   * unlock time does not grow with attachment size.
   */
  async unlock(password: string): Promise<VaultStatus> {
    if (!this.keyring) throw new VaultError('VAULT_MISSING');
    let dek: CryptoKey;
    try {
      dek = await unlockKeyring(password, this.keyring);
    } catch (error) {
      throw this.mapCryptoError(error);
    }
    const records = await this.store.listItemRecords();
    const summaries = new Map<string, ItemSummary>();
    for (const record of records) {
      const entry = await decryptJson<ItemIndexEntry>(dek, record.indexEnv, indexAad(record.id));
      summaries.set(record.id, {
        ...entry,
        id: record.id,
        createdAt: record.createdAt,
        updatedAt: record.updatedAt,
        deletedAt: record.deletedAt,
      });
    }
    this.summaries = summaries;
    this.index.rebuild([...summaries.values()]);
    this.session.open(dek);
    return this.status();
  }

  lock(): void {
    this.session.lock('manual');
  }

  /** Drops every decrypted projection. Called automatically on lock. */
  private forgetPlaintext(): void {
    this.summaries = new Map();
    this.index.clear();
  }

  async changePassword(currentPassword: string, newPassword: string): Promise<void> {
    if (!this.keyring || !this.meta) throw new VaultError('VAULT_MISSING');
    let next: Keyring;
    try {
      next = await rewrapKeyring(currentPassword, newPassword, this.keyring);
    } catch (error) {
      throw this.mapCryptoError(error);
    }
    // Only the 32-byte DEK is rewrapped; user data is untouched, so an
    // interrupted change can never orphan items.
    const meta: VaultMetaRecord = { ...this.meta, keyring: next, updatedAt: this.now() };
    await this.store.writeMeta(meta);
    this.meta = meta;
    this.keyring = next;
  }

  exportKeyring(): Keyring {
    if (!this.keyring) throw new VaultError('VAULT_MISSING');
    return this.keyring;
  }

  // ---- reads ------------------------------------------------------------
  search(query: SearchQuery = {}): ItemSummary[] {
    this.assertUnlocked();
    return this.index.search(query);
  }

  facets() {
    this.assertUnlocked();
    return this.index.facets();
  }

  recent(limit = 8): ItemSummary[] {
    return this.search({ sort: 'updated_desc' }).slice(0, limit);
  }

  trash(): ItemSummary[] {
    this.assertUnlocked();
    return this.index.search({ scope: 'trash', sort: 'updated_desc' });
  }

  async getItem(id: string): Promise<VaultItem> {
    const dek = this.requireKey();
    const record = await this.store.getItemRecord(id);
    if (!record) throw new VaultError('ITEM_NOT_FOUND');
    const entry = await decryptJson<ItemIndexEntry>(dek, record.indexEnv, indexAad(id));
    const content = await decryptJson<ItemContent>(dek, record.contentEnv, contentAad(id));
    return {
      ...entry,
      ...content,
      id,
      createdAt: record.createdAt,
      updatedAt: record.updatedAt,
      deletedAt: record.deletedAt,
    };
  }

  // ---- writes -----------------------------------------------------------
  async createItem(draft: ItemDraft, files: NewFileInput[] = []): Promise<ItemSummary> {
    const dek = this.requireKey();
    const normalized = normalizeDraft(draft);
    const id = randomId();
    const timestamp = this.now();

    const prepared = await this.prepareFiles(dek, id, files);
    const content: ItemContent = {
      body: normalized.body,
      fields: normalized.fields,
      attachments: prepared.attachments,
      url: normalized.url,
    };
    const entry: ItemIndexEntry = {
      title: normalized.title,
      type: normalized.type,
      category: normalized.category,
      tags: normalized.tags,
      preview: buildPreview(normalized.body, normalized.fields),
      attachmentCount: prepared.attachments.length,
      favorite: normalized.favorite,
    };

    // All cryptography happens before any transaction is opened.
    const indexEnv = await encryptJson(dek, entry, indexAad(id));
    const contentEnv = await encryptJson(dek, content, contentAad(id));
    const record: ItemRecord = {
      id,
      createdAt: timestamp,
      updatedAt: timestamp,
      deletedAt: null,
      indexEnv,
      contentEnv,
      attachments: prepared.refs,
    };
    await this.store.putItemWithBlobs(record, prepared.chunks);

    const summary: ItemSummary = { ...entry, id, createdAt: timestamp, updatedAt: timestamp, deletedAt: null };
    this.summaries.set(id, summary);
    this.index.upsert(summary);
    this.session.touch();
    return summary;
  }

  async updateItem(id: string, patch: Partial<ItemDraft>): Promise<ItemSummary> {
    const dek = this.requireKey();
    const existing = await this.getItem(id);
    const normalized = normalizeDraft({
      title: patch.title ?? existing.title,
      type: patch.type ?? existing.type,
      category: patch.category !== undefined ? patch.category : existing.category,
      tags: patch.tags ?? existing.tags,
      body: patch.body !== undefined ? patch.body : existing.body,
      fields: patch.fields ?? existing.fields,
      url: patch.url !== undefined ? patch.url : existing.url,
      favorite: patch.favorite !== undefined ? patch.favorite : existing.favorite,
    });
    const timestamp = this.now();
    const content: ItemContent = {
      body: normalized.body,
      fields: normalized.fields,
      attachments: existing.attachments,
      url: normalized.url,
    };
    const entry: ItemIndexEntry = {
      title: normalized.title,
      type: normalized.type,
      category: normalized.category,
      tags: normalized.tags,
      preview: buildPreview(normalized.body, normalized.fields),
      attachmentCount: existing.attachments.length,
      favorite: normalized.favorite,
    };
    const indexEnv = await encryptJson(dek, entry, indexAad(id));
    const contentEnv = await encryptJson(dek, content, contentAad(id));
    const record = await this.store.getItemRecord(id);
    if (!record) throw new VaultError('ITEM_NOT_FOUND');
    await this.store.putItem({ ...record, indexEnv, contentEnv, updatedAt: timestamp });

    const summary: ItemSummary = {
      ...entry,
      id,
      createdAt: existing.createdAt,
      updatedAt: timestamp,
      deletedAt: existing.deletedAt,
    };
    this.summaries.set(id, summary);
    this.index.upsert(summary);
    this.session.touch();
    return summary;
  }

  async duplicateItem(id: string): Promise<ItemSummary> {
    const source = await this.getItem(id);
    const files: NewFileInput[] = [];
    for (const attachment of source.attachments) {
      const file = await this.readAttachment(id, attachment.blobId);
      files.push(file);
    }
    return this.createItem(
      {
        title: `${source.title} (copy)`,
        type: source.type,
        category: source.category,
        tags: source.tags,
        body: source.body,
        fields: source.fields,
        url: source.url,
        favorite: false,
      },
      files,
    );
  }

  /** Soft delete: the record stays encrypted in place and is recoverable. */
  async moveToTrash(id: string): Promise<void> {
    this.requireKey();
    const record = await this.store.getItemRecord(id);
    if (!record) throw new VaultError('ITEM_NOT_FOUND');
    const deletedAt = this.now();
    await this.store.putItem({ ...record, deletedAt, updatedAt: deletedAt });
    const summary = this.summaries.get(id);
    if (summary) {
      const next = { ...summary, deletedAt, updatedAt: deletedAt };
      this.summaries.set(id, next);
      this.index.upsert(next);
    }
    this.session.touch();
  }

  async restoreFromTrash(id: string): Promise<void> {
    this.requireKey();
    const record = await this.store.getItemRecord(id);
    if (!record) throw new VaultError('ITEM_NOT_FOUND');
    const timestamp = this.now();
    await this.store.putItem({ ...record, deletedAt: null, updatedAt: timestamp });
    const summary = this.summaries.get(id);
    if (summary) {
      const next = { ...summary, deletedAt: null, updatedAt: timestamp };
      this.summaries.set(id, next);
      this.index.upsert(next);
    }
    this.session.touch();
  }

  async deleteForever(id: string): Promise<void> {
    this.requireKey();
    const record = await this.store.getItemRecord(id);
    if (!record) throw new VaultError('ITEM_NOT_FOUND');
    await this.store.deleteItemAndBlobs(id, record.attachments.map((a) => a.blobId));
    this.summaries.delete(id);
    this.index.remove(id);
    this.session.touch();
  }

  async emptyTrash(): Promise<number> {
    const trashed = this.trash();
    for (const item of trashed) await this.deleteForever(item.id);
    return trashed.length;
  }

  // ---- attachments ------------------------------------------------------
  async attachFiles(id: string, files: NewFileInput[]): Promise<VaultItem> {
    const dek = this.requireKey();
    const existing = await this.getItem(id);
    const prepared = await this.prepareFiles(dek, id, files);
    const content: ItemContent = {
      ...existing,
      attachments: [...existing.attachments, ...prepared.attachments],
    };
    const entry: ItemIndexEntry = {
      title: existing.title,
      type: existing.type,
      category: existing.category,
      tags: existing.tags,
      preview: existing.preview,
      attachmentCount: content.attachments.length,
      favorite: existing.favorite,
    };
    const indexEnv = await encryptJson(dek, entry, indexAad(id));
    const contentEnv = await encryptJson(dek, content, contentAad(id));
    const record = await this.store.getItemRecord(id);
    if (!record) throw new VaultError('ITEM_NOT_FOUND');
    const timestamp = this.now();
    await this.store.putItemWithBlobs(
      {
        ...record,
        indexEnv,
        contentEnv,
        updatedAt: timestamp,
        attachments: [...record.attachments, ...prepared.refs],
      },
      prepared.chunks,
    );
    const summary: ItemSummary = { ...entry, id, createdAt: record.createdAt, updatedAt: timestamp, deletedAt: record.deletedAt };
    this.summaries.set(id, summary);
    this.index.upsert(summary);
    return this.getItem(id);
  }

  async readAttachment(itemId: string, blobId: string): Promise<NewFileInput> {
    const dek = this.requireKey();
    const item = await this.getItem(itemId);
    const meta = item.attachments.find((a) => a.blobId === blobId);
    if (!meta) throw new VaultError('ITEM_NOT_FOUND', 'attachment');
    const chunks = await this.store.readBlobChunks(blobId);
    if (chunks.length !== meta.chunks) throw new VaultError('STORAGE_FAILED', 'attachment incomplete');
    const parts: Uint8Array[] = [];
    for (const chunk of chunks) {
      parts.push(await decryptBytes(dek, chunk.env, chunkAad(blobId, chunk.chunk)));
    }
    const total = parts.reduce((sum, p) => sum + p.byteLength, 0);
    const bytes = new Uint8Array(total);
    let offset = 0;
    for (const part of parts) {
      bytes.set(part, offset);
      offset += part.byteLength;
    }
    return { name: meta.name, mime: meta.mime, bytes };
  }

  async removeAttachment(itemId: string, blobId: string): Promise<VaultItem> {
    const dek = this.requireKey();
    const existing = await this.getItem(itemId);
    const attachments = existing.attachments.filter((a) => a.blobId !== blobId);
    const content: ItemContent = { ...existing, attachments };
    const entry: ItemIndexEntry = {
      title: existing.title,
      type: existing.type,
      category: existing.category,
      tags: existing.tags,
      preview: existing.preview,
      attachmentCount: attachments.length,
      favorite: existing.favorite,
    };
    const indexEnv = await encryptJson(dek, entry, indexAad(itemId));
    const contentEnv = await encryptJson(dek, content, contentAad(itemId));
    const record = await this.store.getItemRecord(itemId);
    if (!record) throw new VaultError('ITEM_NOT_FOUND');
    const timestamp = this.now();
    await this.store.putItem({
      ...record,
      indexEnv,
      contentEnv,
      updatedAt: timestamp,
      attachments: record.attachments.filter((a) => a.blobId !== blobId),
    });
    await this.store.deleteBlobs([blobId]);
    const summary: ItemSummary = { ...entry, id: itemId, createdAt: record.createdAt, updatedAt: timestamp, deletedAt: record.deletedAt };
    this.summaries.set(itemId, summary);
    this.index.upsert(summary);
    return this.getItem(itemId);
  }

  private async prepareFiles(
    dek: CryptoKey,
    itemId: string,
    files: NewFileInput[],
  ): Promise<{ attachments: AttachmentMeta[]; refs: AttachmentRef[]; chunks: BlobChunkRecord[] }> {
    const attachments: AttachmentMeta[] = [];
    const refs: AttachmentRef[] = [];
    const chunks: BlobChunkRecord[] = [];
    for (const file of files) {
      if (file.bytes.byteLength > LIMITS.fileMaxBytes) throw new VaultError('FILE_TOO_LARGE');
      const blobId = randomId();
      const count = Math.max(1, Math.ceil(file.bytes.byteLength / CHUNK_BYTES));
      for (let i = 0; i < count; i += 1) {
        const slice = file.bytes.subarray(i * CHUNK_BYTES, Math.min((i + 1) * CHUNK_BYTES, file.bytes.byteLength));
        const env: Envelope = await encryptBytes(dek, slice, chunkAad(blobId, i));
        chunks.push({ blobId, chunk: i, itemId, env });
      }
      attachments.push({
        blobId,
        name: sanitizeFilename(file.name),
        mime: file.mime || 'application/octet-stream',
        size: file.bytes.byteLength,
        addedAt: this.now(),
        chunks: count,
      });
      refs.push({ blobId, size: file.bytes.byteLength, chunks: count });
    }
    return { attachments, refs, chunks };
  }

  // ---- backup / restore -------------------------------------------------
  /** Encrypted backup of the whole vault. Requires an unlocked session. */
  async createBackupFile(): Promise<Uint8Array> {
    this.requireKey();
    const bytes = await createBackup(this.store, '', this.exportKeyring(), this.options.appVersion);
    this.session.touch();
    return bytes;
  }

  /**
   * Restores a backup using the password that was active when it was made.
   * Works on a fresh device (no vault yet) and on an existing vault. The
   * backup keyring is unlocked with the password, every envelope is verified
   * with the backup DEK, and only then is the live DB replaced in one
   * transaction. On success the vault is unlocked with the restored keyring.
   */
  async restoreBackupFile(bytes: Uint8Array, password: string): Promise<VaultStatus> {
    const validated = await validateBackup(bytes);
    let dek: CryptoKey;
    try {
      dek = await unlockKeyring(password, validated.bundle.keyring);
    } catch {
      throw new VaultError('BACKUP_WRONG_PASSWORD');
    }
    await verifyBackupEnvelopes(validated, dek);
    const timestamp = this.now();
    const meta: VaultMetaRecord = {
      key: META_KEY,
      schemaVersion: DB_VERSION,
      appVersion: this.options.appVersion,
      keyring: validated.bundle.keyring,
      createdAt: this.meta?.createdAt ?? timestamp,
      updatedAt: timestamp,
    };
    if (this.session.isUnlocked) this.session.lock('manual');
    try {
      await this.store.replaceAll({ meta, items: validated.items, blobs: validated.blobs });
    } catch {
      throw new VaultError('RESTORE_FAILED');
    }
    await this.load();
    return this.unlock(password);
  }

  // ---- internals --------------------------------------------------------
  private assertUnlocked(): void {
    if (!this.session.isUnlocked) throw new VaultError('LOCKED');
  }

  private requireKey(): CryptoKey {
    this.assertUnlocked();
    return this.session.requireKey();
  }

  private mapCryptoError(error: unknown): VaultError {
    if (error instanceof VaultCryptoError) {
      if (error.code === 'WRONG_PASSWORD') return new VaultError('WRONG_PASSWORD');
      if (error.code === 'WEAK_PASSWORD') return new VaultError('WEAK_PASSWORD');
      return new VaultError('STORAGE_FAILED', error.code);
    }
    return new VaultError('STORAGE_FAILED');
  }

  /** Used by the backup layer, which needs raw records, not projections. */
  internals() {
    return {
      store: this.store,
      session: this.session,
      indexAad,
      contentAad,
      chunkAad,
      refreshAfterRestore: async () => {
        await this.load();
      },
    };
  }
}
