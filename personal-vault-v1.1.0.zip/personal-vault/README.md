# Personal Vault

A local-first, offline-capable personal vault for Chrome Extension and Android. Personal Vault keeps primary user data on the device, encrypts it with Web Crypto, and shares one TypeScript core across both shells.

> **Status:** v1.1.0. The web UI is now wired to the real encrypted core (IndexedDB + AES-GCM + PBKDF2). The crypto, domain, persistence, backup validation, UI, MV3 manifest, Android shell and CI definitions are included. GitHub Actions is the authoritative environment for npm, Vite and Android builds because this workspace intentionally has no network, npm or Android SDK.

## Architecture

```text
Extension / Android Shell
          ↓
     React Web App
          ↓
  @pv/core application layer
          ↓
 @pv/crypto Web Crypto primitives
          ↓
      IndexedDB
```

The Android app loads bundled assets through `WebViewAssetLoader` at `https://appassets.androidplatform.net/assets/web/index.html` (APK path `assets/web/`). It does not run a local HTTP server and does not request broad storage permissions.

## Security architecture

- AES-GCM 256-bit with a fresh 96-bit IV per envelope.
- PBKDF2-SHA-256 with a per-vault salt and 600,000 iterations.
- Password derives a non-extractable KEK. The KEK wraps a random independent DEK. The DEK encrypts items and file chunks.
- AAD binds every item and blob to its identity and version.
- Search uses an encrypted lightweight index projection. Bodies and attachments are lazy.
- Password changes rewrap the DEK only. User data is not re-encrypted.
- Lock drops the DEK and decrypted projections. JavaScript memory cannot provide an absolute physical wipe guarantee.

## Features in this build

Vault lifecycle, session/autolock, encrypted item CRUD, soft delete/trash/restore/permanent delete, duplicate, tags/categories/types, Persian-aware search and sorting, encrypted chunked attachments, file-type preview classification, versioned IndexedDB schema and migrations, validated backup envelope, atomic restore path, RTL responsive UI, light/dark themes, Chrome MV3 shell, Android WebViewAssetLoader shell, CI workflows, and offline Node tests.

## Repository

- `apps/web-shell`: shared React/Vite app
- `apps/extension`: Manifest V3 wrapper and extension build
- `apps/android`: Kotlin-free Java shell using AndroidX WebKit
- `packages/core`: domain, storage, vault service, search, backup and file handling
- `packages/crypto`: Web Crypto key hierarchy and primitives
- `packages/ui`: design tokens
- `docs`: architecture and security decisions
- `.github/workflows`: quality, extension and APK builds

## Development

```bash
npm ci
npm run typecheck
npm run lint
npm run test:node
npm run build:web
npm run build:extension
npm run verify:no-localhost
```

The root scripts expect Node 20+ and npm 10+. The build does not use a CDN, Google Fonts, remote JavaScript, or a runtime API.

## Android

`.github/workflows/main.yml` builds the web assets, copies them into `apps/android/app/src/main/assets/web` with `npm run android:sync` (which fails on missing or absolute asset paths), installs Gradle 8.10.2 and Android SDK 35, builds `assembleDebug`, verifies the APK contains the bundled index, and uploads the APK artifact. Runtime verification on a device should still include install, launch, vault creation, lock/unlock, backup/restore, file picker and rotation/background checks.

## Chrome Extension

The extension has only the `storage` permission and a strict Manifest V3 extension-page CSP. Build output is zipped by CI as `personal-vault-extension.zip`.

## Backups

v1 uses a self-describing encrypted-record container. It stores the manifest, version, hashes, encrypted item records, encrypted file chunks, and the wrapped keyring. Restore validates structure, version, counts, every hash, every item envelope and every blob envelope before one atomic store replacement. A future ZIP transport can wrap the same payload without changing its cryptographic protocol.

## Testing and known limits

The checked-in Node tests exercise AES-GCM round trips, AAD tamper rejection, wrong-password rejection and Persian-aware search. The full browser IndexedDB and Android runtime matrix belongs in CI/device testing. Password recovery is intentionally unavailable without an independent backup or recovery key. A lost master password cannot be bypassed.

## Release

Use semantic tags such as `v1.0.0`. Release artifacts are the debug APK and extension ZIP from Actions. Do not commit `.env` files, signing keys, API keys, or real vault data.

## Stable APK signing (recommended)

Without secrets, CI signs the debug APK with a fresh auto-generated debug key on every run, so a newer build will not install over an older one (uninstall first, after exporting a backup). To keep one key, add these repository secrets:

| Secret | Value |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | `base64 -w0 my.jks` |
| `ANDROID_KEYSTORE_PASSWORD` | keystore password |
| `ANDROID_KEY_ALIAS` | key alias |
| `ANDROID_KEY_PASSWORD` | key password |

Create a key once with `keytool -genkeypair -v -keystore my.jks -alias pv -keyalg RSA -keysize 4096 -validity 10000`. Never commit it.
