import { readFile, readdir } from 'node:fs/promises'; import { join } from 'node:path';
const roots=['apps','packages','scripts','.github']; const bad=/https?:\/\/(?:localhost|127\.0\.0\.1)|127\.0\.0\.1|localhost/;
async function walk(dir){let out=[]; for(const x of await readdir(dir,{withFileTypes:true})){if(['node_modules','.gradle','build','dist'].includes(x.name))continue; const p=join(dir,x.name); if(x.isDirectory())out.push(...await walk(p)); else out.push(p)} return out}
const files=(await Promise.all(roots.map(walk))).flat().filter((p) => !p.endsWith('verify-no-localhost.mjs') && !p.startsWith('.github/workflows/')); let failed=[]; for(const p of files){const s=await readFile(p,'utf8').catch(()=>null); if(s&&bad.test(s))failed.push(p)}
if(failed.length){console.error('Forbidden localhost references:',failed.join('\n'));process.exit(1)} console.log(`No localhost or loopback references found in ${files.length} source files.`);
