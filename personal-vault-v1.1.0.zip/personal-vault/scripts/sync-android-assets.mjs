// Copies the Vite build into the Android APK assets and verifies that every
// file referenced by index.html actually exists, so a broken path fails the
// build instead of shipping a blank WebView.
import { cp, mkdir, readFile, readdir, rm, stat } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const dist = join(root, 'apps/web-shell/dist');
const target = join(root, 'apps/android/app/src/main/assets/web');

function fail(message) {
  console.error(`android:sync failed: ${message}`);
  process.exit(1);
}

const indexPath = join(dist, 'index.html');
try {
  await stat(indexPath);
} catch {
  fail(`missing ${indexPath}. Run "npm run build:web" first.`);
}

await rm(target, { recursive: true, force: true });
await mkdir(target, { recursive: true });
await cp(dist, target, { recursive: true });

const html = await readFile(join(target, 'index.html'), 'utf8');
const refs = [...html.matchAll(/(?:src|href)="([^"]+)"/g)].map((m) => m[1]);
if (refs.length === 0) fail('index.html references no assets');
const problems = [];
for (const ref of refs) {
  if (/^(https?:)?\/\//i.test(ref)) problems.push(`remote reference not allowed: ${ref}`);
  else if (ref.startsWith('/')) problems.push(`absolute path breaks WebViewAssetLoader: ${ref} (set base: './')`);
  else {
    try {
      await stat(join(target, ref));
    } catch {
      problems.push(`referenced file missing: ${ref}`);
    }
  }
}
const loopback = new RegExp(['local' + 'host', '127\\.0\\.0\\.1'].join('|'));
if (loopback.test(html)) problems.push('index.html references a loopback address');
if (problems.length) fail(`\n  ${problems.join('\n  ')}`);

async function walk(dir) {
  const out = [];
  for (const e of await readdir(dir, { withFileTypes: true })) {
    const p = join(dir, e.name);
    if (e.isDirectory()) out.push(...(await walk(p)));
    else out.push(p);
  }
  return out;
}
const files = await walk(target);
console.log(`android:sync OK: ${files.length} files -> apps/android/app/src/main/assets/web`);
for (const ref of refs) console.log(`  ✓ ${ref}`);
