import test from 'node:test'; import assert from 'node:assert/strict';
const {SearchIndex}=await import('../../packages/core/src/search/searchIndex.ts');
const idx=new SearchIndex(); idx.rebuild([{id:'1',title:'پاسپورت',type:'personal',category:'سفر',tags:['مهم'],preview:'مدرک',attachmentCount:0,favorite:true,createdAt:1,updatedAt:3,deletedAt:null},{id:'2',title:'ایده محصول',type:'note',category:'کار',tags:[],preview:'یادداشت',attachmentCount:0,favorite:false,createdAt:2,updatedAt:2,deletedAt:null}]);
test('search filters and Persian normalization',()=>{assert.equal(idx.search({text:'پاسپورت'}).length,1); assert.equal(idx.search({types:['note']}).length,1); assert.equal(idx.search({favoritesOnly:true}).length,1);});
