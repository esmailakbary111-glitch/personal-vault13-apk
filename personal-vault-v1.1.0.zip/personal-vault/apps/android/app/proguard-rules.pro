# Keep the JavaScript bridge method names used by the web app.
-keepclassmembers class com.personalvault.app.MainActivity$FileBridge {
    @android.webkit.JavascriptInterface <methods>;
}
