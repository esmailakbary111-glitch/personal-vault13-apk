package com.personalvault.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;
import java.io.OutputStream;

/**
 * Offline shell. The UI is bundled in APK assets (assets/web/) and served by
 * WebViewAssetLoader at https://appassets.androidplatform.net/assets/web/.
 * There is deliberately no INTERNET permission and no local network server.
 */
public final class MainActivity extends Activity {
  static final String HOST = "appassets.androidplatform.net";
  static final String START_URL = "https://" + HOST + "/assets/web/index.html";
  private static final int REQ_PICK_FILE = 4101;
  private static final int REQ_SAVE_FILE = 4102;

  private WebView webView;
  @Nullable private ValueCallback<Uri[]> fileCallback;
  @Nullable private byte[] pendingSave;

  @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
  @Override
  public void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    // Keep vault contents out of the recents thumbnail and screenshots.
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);

    webView = new WebView(this);
    webView.setBackgroundColor(getResources().getColor(R.color.pv_bg, getTheme()));
    setContentView(webView);

    final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
        .setDomain(HOST)
        .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
        .build();

    webView.setWebViewClient(new WebViewClientCompat() {
      @Override
      public WebResourceResponse shouldInterceptRequest(@NonNull WebView view, @NonNull WebResourceRequest request) {
        return loader.shouldInterceptRequest(request.getUrl());
      }

      @Override
      @SuppressWarnings("deprecation")
      public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
        return loader.shouldInterceptRequest(Uri.parse(url));
      }

      @Override
      public boolean shouldOverrideUrlLoading(@NonNull WebView view, @NonNull WebResourceRequest request) {
        // Only the bundled app may load inside the WebView. External links
        // (saved in vault items) open in the system browser instead.
        Uri uri = request.getUrl();
        if (HOST.equals(uri.getHost())) return false;
        String scheme = uri.getScheme();
        if ("https".equals(scheme) || "http".equals(scheme) || "mailto".equals(scheme)) {
          try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
          } catch (ActivityNotFoundException ignored) {
            // nothing to open it with
          }
        }
        return true;
      }
    });

    webView.setWebChromeClient(new WebChromeClient() {
      @Override
      public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        fileCallback = callback;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
          intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        }
        try {
          startActivityForResult(intent, REQ_PICK_FILE);
          return true;
        } catch (ActivityNotFoundException e) {
          fileCallback = null;
          return false;
        }
      }
    });

    WebSettings s = webView.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setDatabaseEnabled(true);
    s.setAllowFileAccess(false);
    s.setAllowContentAccess(false);
    s.setAllowFileAccessFromFileURLs(false);
    s.setAllowUniversalAccessFromFileURLs(false);
    s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    s.setSupportMultipleWindows(false);
    s.setJavaScriptCanOpenWindowsAutomatically(false);
    s.setGeolocationEnabled(false);
    s.setSaveFormData(false);
    s.setMediaPlaybackRequiresUserGesture(true);
    s.setTextZoom(100);
    WebView.setWebContentsDebuggingEnabled((getApplicationInfo().flags & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0);

    webView.addJavascriptInterface(new FileBridge(), "PVAndroid");

    if (savedInstanceState == null) {
      webView.loadUrl(START_URL);
    } else {
      webView.restoreState(savedInstanceState);
      if (webView.getUrl() == null) webView.loadUrl(START_URL);
    }
  }

  /** Lets the web app save backups/attachments: WebView cannot download blob: URLs. */
  final class FileBridge {
    @JavascriptInterface
    public void saveFile(final String name, final String mime, final String base64) {
      final byte[] bytes;
      try {
        bytes = Base64.decode(base64, Base64.DEFAULT);
      } catch (IllegalArgumentException e) {
        notifySaved(false);
        return;
      }
      runOnUiThread(() -> {
        pendingSave = bytes;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
        intent.putExtra(Intent.EXTRA_TITLE, name == null || name.isEmpty() ? "file" : name);
        try {
          startActivityForResult(intent, REQ_SAVE_FILE);
        } catch (ActivityNotFoundException e) {
          pendingSave = null;
          notifySaved(false);
        }
      });
    }
  }

  private void notifySaved(final boolean ok) {
    runOnUiThread(() -> {
      if (webView != null) {
        webView.evaluateJavascript("window.dispatchEvent(new CustomEvent('pv:saved',{detail:" + ok + "}))", null);
      }
    });
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == REQ_PICK_FILE) {
      if (fileCallback == null) return;
      Uri[] result = null;
      if (resultCode == RESULT_OK && data != null) {
        ClipData clip = data.getClipData();
        if (clip != null && clip.getItemCount() > 0) {
          result = new Uri[clip.getItemCount()];
          for (int i = 0; i < clip.getItemCount(); i++) result[i] = clip.getItemAt(i).getUri();
        } else if (data.getData() != null) {
          result = new Uri[] {data.getData()};
        }
      }
      fileCallback.onReceiveValue(result);
      fileCallback = null;
    } else if (requestCode == REQ_SAVE_FILE) {
      byte[] bytes = pendingSave;
      pendingSave = null;
      boolean ok = false;
      if (resultCode == RESULT_OK && data != null && data.getData() != null && bytes != null) {
        try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
          if (out != null) {
            out.write(bytes);
            ok = true;
          }
        } catch (Exception ignored) {
          ok = false;
        }
      }
      notifySaved(ok);
    }
  }

  @Override
  protected void onSaveInstanceState(@NonNull Bundle outState) {
    super.onSaveInstanceState(outState);
    if (webView != null) webView.saveState(outState);
  }

  @Override
  public void onConfigurationChanged(@NonNull Configuration newConfig) {
    super.onConfigurationChanged(newConfig);
    // configChanges keeps the Activity (and the unlocked session) alive.
  }

  @Override
  @SuppressWarnings("deprecation")
  public void onBackPressed() {
    if (webView != null && webView.canGoBack()) webView.goBack();
    else super.onBackPressed();
  }

  @Override
  protected void onPause() {
    super.onPause();
    if (webView != null) webView.evaluateJavascript("window.dispatchEvent(new Event('pv:hidden'))", null);
  }

  @Override
  protected void onResume() {
    super.onResume();
    if (webView != null) webView.evaluateJavascript("window.dispatchEvent(new Event('pv:visible'))", null);
  }

  @Override
  protected void onDestroy() {
    if (fileCallback != null) {
      fileCallback.onReceiveValue(null);
      fileCallback = null;
    }
    if (webView != null) {
      webView.removeJavascriptInterface("PVAndroid");
      webView.destroy();
      webView = null;
    }
    super.onDestroy();
  }
}
