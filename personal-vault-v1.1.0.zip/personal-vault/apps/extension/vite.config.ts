import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath, URL } from 'node:url';

const here = (p: string) => fileURLToPath(new URL(p, import.meta.url));

export default defineConfig({
  plugins: [react()],
  root: here('../web-shell'),
  base: './',
  resolve: {
    alias: {
      '@pv/core': here('../../packages/core/src'),
      '@pv/crypto': here('../../packages/crypto/src'),
      '@pv/ui': here('../../packages/ui/src'),
    },
  },
  build: {
    outDir: here('./dist'),
    emptyOutDir: true,
    target: ['es2020', 'chrome100'],
    modulePreload: { polyfill: false },
    rollupOptions: { input: here('../web-shell/index.html') },
  },
});
