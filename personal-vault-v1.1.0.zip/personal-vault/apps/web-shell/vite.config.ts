import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath, URL } from 'node:url';

/**
 * Strict CSP, injected only into production HTML (the dev server needs inline
 * scripts for React refresh). No remote origins: the app is fully offline.
 */
const CSP = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' blob: data:",
  "font-src 'self'",
  "connect-src 'self'",
  "object-src 'none'",
  "base-uri 'none'",
  "form-action 'none'",
].join('; ');

function csp(): Plugin {
  return {
    name: 'pv-csp',
    apply: 'build',
    transformIndexHtml(html) {
      return html.replace('<head>', `<head>\n    <meta http-equiv="Content-Security-Policy" content="${CSP}" />`);
    },
  };
}

export default defineConfig({
  // Relative asset URLs are required: Android serves the build from
  // https://appassets.androidplatform.net/assets/web/ and the extension from
  // chrome-extension://<id>/. An absolute "/assets/..." path breaks both.
  base: './',
  plugins: [react(), csp()],
  resolve: {
    alias: {
      '@pv/core': fileURLToPath(new URL('../../packages/core/src', import.meta.url)),
      '@pv/crypto': fileURLToPath(new URL('../../packages/crypto/src', import.meta.url)),
      '@pv/ui': fileURLToPath(new URL('../../packages/ui/src', import.meta.url)),
    },
  },
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    sourcemap: false,
    // Android System WebView on API 26 devices can be old; stay conservative.
    target: ['es2020', 'chrome87', 'safari14', 'firefox78'],
    modulePreload: { polyfill: false },
    chunkSizeWarningLimit: 800,
  },
});
