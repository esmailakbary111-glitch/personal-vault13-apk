import { useRef, useState } from 'react';
import { AUTO_LOCK_PRESETS_MS, type Settings, type ThemeMode, type VaultService, type VaultStatus } from '@pv/core';
import { Icon, Sheet, Spinner, Toggle } from './ui.tsx';
import { AUTO_LOCK_LABELS, dateLabel, errorText, fa } from './i18n.ts';
import { PasswordInput, StrengthMeter } from './auth.tsx';
import { assessPassword } from '@pv/crypto';
import { readFile, saveBytes } from './files.ts';
import { APP_VERSION, beginExternalActivity, endExternalActivity } from './vaultClient.ts';

export function SettingsView({
  service,
  settings,
  status,
  onSettings,
  onLock,
  onToast,
  onError,
  onRestored,
}: {
  service: VaultService;
  settings: Settings;
  status: VaultStatus;
  onSettings: (patch: Partial<Settings>) => void;
  onLock: () => void;
  onToast: (t: string) => void;
  onError: (t: string) => void;
  onRestored: () => void;
}) {
  const [pwOpen, setPwOpen] = useState(false);
  const [restoreFile, setRestoreFile] = useState<Uint8Array | null>(null);
  const [exporting, setExporting] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const themes: { v: ThemeMode; label: string; icon: string }[] = [
    { v: 'system', label: 'سیستم', icon: 'grid' },
    { v: 'light', label: 'روشن', icon: 'sun' },
    { v: 'dark', label: 'تیره', icon: 'moon' },
  ];

  return (
    <div className="settings">
      <section className="set-group">
        <h3>ظاهر</h3>
        <div className="set-row">
          <div>
            <strong>پوسته</strong>
            <p>پیش‌فرض از تنظیمات دستگاه پیروی می‌کند.</p>
          </div>
          <div className="segmented" role="radiogroup" aria-label="پوسته">
            {themes.map((t) => (
              <button type="button" key={t.v} role="radio" aria-checked={settings.theme === t.v} className={settings.theme === t.v ? 'on' : ''} onClick={() => onSettings({ theme: t.v })}>
                <Icon name={t.icon} size={16} /> {t.label}
              </button>
            ))}
          </div>
        </div>
        <div className="set-row">
          <div>
            <strong>پیش‌نمایش متن در فهرست</strong>
            <p>روی صفحه‌های عمومی خاموشش کن.</p>
          </div>
          <Toggle label="پیش‌نمایش" checked={settings.showPreviews} onChange={(v) => onSettings({ showPreviews: v })} />
        </div>
      </section>

      <section className="set-group">
        <h3>امنیت</h3>
        <div className="set-row">
          <div>
            <strong>قفل خودکار</strong>
            <p>بعد از این مدت بی‌فعالیتی کلید از حافظه پاک می‌شود.</p>
          </div>
          <select value={settings.autoLockMs} onChange={(e) => onSettings({ autoLockMs: Number(e.target.value) })} aria-label="قفل خودکار">
            {AUTO_LOCK_PRESETS_MS.map((ms) => (
              <option key={ms} value={ms}>
                {AUTO_LOCK_LABELS[ms]}
              </option>
            ))}
          </select>
        </div>
        <div className="set-row">
          <div>
            <strong>قفل هنگام خروج از برنامه</strong>
            <p>با رفتن به پس‌زمینه، Vault فوراً قفل شود.</p>
          </div>
          <Toggle label="قفل در پس‌زمینه" checked={settings.lockOnBackground} onChange={(v) => onSettings({ lockOnBackground: v })} />
        </div>
        <div className="set-row">
          <div>
            <strong>پاک کردن کلیپ‌بورد</strong>
            <p>مقدار کپی‌شده بعد از این مدت پاک می‌شود.</p>
          </div>
          <select value={settings.clipboardClearSeconds} onChange={(e) => onSettings({ clipboardClearSeconds: Number(e.target.value) })} aria-label="پاک کردن کلیپ‌بورد">
            {[0, 15, 30, 60, 120].map((s) => (
              <option key={s} value={s}>
                {s === 0 ? 'هرگز' : `${fa(s)} ثانیه`}
              </option>
            ))}
          </select>
        </div>
        <div className="set-row">
          <div>
            <strong>رمز عبور اصلی</strong>
            <p>فقط کلید داده دوباره بسته‌بندی می‌شود؛ داده‌ها دست نمی‌خورند.</p>
          </div>
          <button type="button" className="btn" onClick={() => setPwOpen(true)}>
            <Icon name="key" size={18} /> تغییر رمز
          </button>
        </div>
        <div className="set-row">
          <div>
            <strong>قفل دستی</strong>
            <p>کلید رمزگشایی همین حالا از حافظه حذف می‌شود.</p>
          </div>
          <button type="button" className="btn" onClick={onLock}>
            <Icon name="lock" size={18} /> قفل کن
          </button>
        </div>
      </section>

      <section className="set-group">
        <h3>پشتیبان‌گیری</h3>
        <div className="set-row">
          <div>
            <strong>ساخت فایل پشتیبان</strong>
            <p>فایل رمزنگاری‌شده است و فقط با رمز فعلی باز می‌شود.</p>
          </div>
          <button
            type="button"
            className="btn btn-primary"
            disabled={exporting}
            onClick={async () => {
              setExporting(true);
              try {
                const bytes = await service.createBackupFile();
                const d = new Date();
                const stamp = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
                saveBytes(bytes, `personal-vault-${stamp}.pvbackup`, 'application/octet-stream');
                onToast('فایل پشتیبان آماده شد');
              } catch (e) {
                onError(errorText(e));
              } finally {
                setExporting(false);
              }
            }}
          >
            {exporting ? <Spinner /> : <Icon name="download" size={18} />} پشتیبان
          </button>
        </div>
        <div className="set-row">
          <div>
            <strong>بازیابی</strong>
            <p>کل محتوای فعلی با پشتیبان جایگزین می‌شود.</p>
          </div>
          <button
            type="button"
            className="btn"
            onClick={() => {
              beginExternalActivity();
              input.current?.click();
            }}
          >
            <Icon name="upload" size={18} /> انتخاب فایل
          </button>
          <input
            ref={input}
            type="file"
            hidden
            accept=".pvbackup,.json,application/json,application/octet-stream"
            onChange={async (e) => {
              endExternalActivity();
              const f = e.target.files?.[0];
              e.target.value = '';
              if (f) setRestoreFile((await readFile(f)).bytes);
            }}
          />
        </div>
      </section>

      <section className="set-group about">
        <h3>درباره</h3>
        <dl>
          <div><dt>نسخه</dt><dd>{APP_VERSION}</dd></div>
          <div><dt>موارد</dt><dd>{fa(status.itemCount)} فعال · {fa(status.trashCount)} در سطل</dd></div>
          {status.createdAt && <div><dt>ساخته‌شده</dt><dd>{dateLabel(status.createdAt)}</dd></div>}
          <div><dt>رمزنگاری</dt><dd dir="ltr">AES-GCM-256 · PBKDF2-SHA256 × 600k</dd></div>
        </dl>
      </section>

      {pwOpen && <ChangePassword service={service} onClose={() => setPwOpen(false)} onDone={() => { setPwOpen(false); onToast('رمز عبور تغییر کرد'); }} />}
      {restoreFile && (
        <RestoreConfirm
          onClose={() => setRestoreFile(null)}
          onRestore={async (password) => {
            await service.restoreBackupFile(restoreFile, password);
            setRestoreFile(null);
            onRestored();
          }}
        />
      )}
    </div>
  );
}

function ChangePassword({ service, onClose, onDone }: { service: VaultService; onClose: () => void; onDone: () => void }) {
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [again, setAgain] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const ok = current && assessPassword(next).acceptable && next === again && !busy;
  return (
    <Sheet
      title="تغییر رمز عبور اصلی"
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn" onClick={onClose} disabled={busy}>انصراف</button>
          <button
            type="button"
            className="btn btn-primary"
            disabled={!ok}
            onClick={async () => {
              setBusy(true);
              setError('');
              try {
                await service.changePassword(current, next);
                onDone();
              } catch (e) {
                setError(errorText(e));
                setBusy(false);
              }
            }}
          >
            {busy ? <Spinner /> : 'تغییر رمز'}
          </button>
        </>
      }
    >
      <div className="stack">
        <label htmlFor="cp-cur">رمز فعلی</label>
        <PasswordInput id="cp-cur" value={current} onChange={setCurrent} autoFocus autoComplete="current-password" />
        <label htmlFor="cp-new">رمز جدید</label>
        <PasswordInput id="cp-new" value={next} onChange={setNext} autoComplete="new-password" />
        <StrengthMeter password={next} />
        <label htmlFor="cp-again">تکرار رمز جدید</label>
        <PasswordInput id="cp-again" value={again} onChange={setAgain} autoComplete="new-password" invalid={again.length > 0 && again !== next} />
        {error && <p className="form-error" role="alert">{error}</p>}
        <p className="hint">پشتیبان‌های قبلی همچنان با رمز قدیمی باز می‌شوند.</p>
      </div>
    </Sheet>
  );
}

function RestoreConfirm({ onClose, onRestore }: { onClose: () => void; onRestore: (password: string) => Promise<void> }) {
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  return (
    <Sheet
      title="بازیابی از پشتیبان"
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn" onClick={onClose} disabled={busy}>انصراف</button>
          <button
            type="button"
            className="btn btn-danger"
            disabled={!password || busy}
            onClick={async () => {
              setBusy(true);
              setError('');
              try {
                await onRestore(password);
              } catch (e) {
                setError(errorText(e));
                setBusy(false);
              }
            }}
          >
            {busy ? <Spinner /> : 'جایگزینی و بازیابی'}
          </button>
        </>
      }
    >
      <div className="stack">
        <p className="warn-box">
          <Icon name="alert" size={18} /> همه موارد فعلی با محتوای پشتیبان جایگزین می‌شوند. قبل از جایگزینی، کل فایل رمزگشایی و بررسی می‌شود.
        </p>
        <label htmlFor="rs-pw">رمز عبوری که هنگام ساخت پشتیبان فعال بود</label>
        <PasswordInput id="rs-pw" value={password} onChange={setPassword} autoFocus autoComplete="current-password" />
        {error && <p className="form-error" role="alert">{error}</p>}
      </div>
    </Sheet>
  );
}
