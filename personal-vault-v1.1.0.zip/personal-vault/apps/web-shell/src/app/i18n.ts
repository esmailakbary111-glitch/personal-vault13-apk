import type { ItemType } from '@pv/core';

export const TYPE_LABELS: Record<ItemType, string> = {
  note: 'یادداشت',
  text: 'متن',
  personal: 'اطلاعات شخصی',
  credential: 'اعتبارنامه',
  image: 'تصویر',
  file: 'فایل',
  link: 'لینک',
  custom: 'سفارشی',
};

const ERRORS: Record<string, string> = {
  VAULT_EXISTS: 'Vault از قبل روی این دستگاه وجود دارد.',
  VAULT_MISSING: 'هنوز Vault ساخته نشده است.',
  LOCKED: 'Vault قفل است. دوباره وارد شو.',
  WRONG_PASSWORD: 'رمز عبور درست نیست.',
  WEAK_PASSWORD: 'رمز عبور ضعیف است. حداقل ۱۰ کاراکتر با حروف بزرگ و کوچک، عدد و نماد.',
  ITEM_NOT_FOUND: 'این مورد پیدا نشد.',
  VALIDATION_FAILED: 'اطلاعات واردشده معتبر نیست.',
  STORAGE_FAILED: 'ذخیره‌سازی روی دستگاه ناموفق بود.',
  BACKUP_INVALID: 'این فایل پشتیبان معتبر نیست.',
  BACKUP_UNSUPPORTED_VERSION: 'نسخه این فایل پشتیبان پشتیبانی نمی‌شود.',
  BACKUP_INTEGRITY_FAILED: 'فایل پشتیبان آسیب دیده یا دستکاری شده است.',
  BACKUP_WRONG_PASSWORD: 'رمز عبور این فایل پشتیبان درست نیست.',
  RESTORE_FAILED: 'بازیابی انجام نشد. داده‌های فعلی دست‌نخورده باقی ماند.',
  FILE_TOO_LARGE: 'حجم فایل بیشتر از ۲۵ مگابایت است.',
  UNSUPPORTED_MIGRATION: 'نسخه پایگاه داده با این برنامه سازگار نیست.',
};

const VALIDATION_DETAILS: Record<string, string> = {
  'title is required': 'عنوان لازم است.',
  'title too long': 'عنوان خیلی طولانی است.',
  'invalid url': 'آدرس لینک معتبر نیست.',
  'unsupported url scheme': 'فقط لینک‌های http، https و mailto مجازند.',
  'body too long': 'متن خیلی طولانی است.',
};

export function errorText(error: unknown): string {
  const e = error as { code?: string; detail?: string } | null;
  if (e?.code === 'VALIDATION_FAILED' && e.detail && VALIDATION_DETAILS[e.detail]) return VALIDATION_DETAILS[e.detail] as string;
  if (e?.code && ERRORS[e.code]) return ERRORS[e.code] as string;
  return 'خطای غیرمنتظره. دوباره تلاش کن.';
}

const faNumber = new Intl.NumberFormat('fa-IR');
export const fa = (n: number): string => faNumber.format(n);

const rtf = new Intl.RelativeTimeFormat('fa', { numeric: 'auto' });
const dateFmt = new Intl.DateTimeFormat('fa-IR', { day: 'numeric', month: 'long', year: 'numeric' });
const longDate = new Intl.DateTimeFormat('fa-IR', { weekday: 'long', day: 'numeric', month: 'long' });

export function relativeTime(ts: number, now = Date.now()): string {
  const diff = Math.round((ts - now) / 1000);
  const abs = Math.abs(diff);
  if (abs < 45) return 'همین حالا';
  if (abs < 3600) return rtf.format(Math.round(diff / 60), 'minute');
  if (abs < 86_400) return rtf.format(Math.round(diff / 3600), 'hour');
  if (abs < 7 * 86_400) return rtf.format(Math.round(diff / 86_400), 'day');
  return dateFmt.format(ts);
}

export const todayLabel = (): string => longDate.format(Date.now());
export const dateLabel = (ts: number): string => dateFmt.format(ts);

export const AUTO_LOCK_LABELS: Record<number, string> = {
  0: 'فوراً (با خروج از برنامه)',
  60_000: '۱ دقیقه',
  300_000: '۵ دقیقه',
  900_000: '۱۵ دقیقه',
  1_800_000: '۳۰ دقیقه',
  3_600_000: '۱ ساعت',
};

export const PASSWORD_ISSUES: Record<string, string> = {
  length: 'حداقل ۱۰ کاراکتر',
  case: 'حروف بزرگ و کوچک لاتین',
  digit: 'یک عدد',
  symbol: 'یک نماد مثل ! یا #',
  repetition: 'بدون تکرار یک کاراکتر',
};
