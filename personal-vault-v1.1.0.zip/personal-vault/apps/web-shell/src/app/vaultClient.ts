import {
  DEFAULT_SETTINGS,
  Session,
  VaultService,
  VaultStore,
  openDatabase,
} from '@pv/core';

export const APP_VERSION = '1.1.0';

export interface VaultClient {
  readonly service: VaultService;
  readonly session: Session;
}

let pending: Promise<VaultClient> | null = null;

/** Opens IndexedDB once and wires the real crypto-backed VaultService. */
export function getVaultClient(): Promise<VaultClient> {
  if (!pending) {
    pending = (async () => {
      const db = await openDatabase({
        onVersionChange: () => window.location.reload(),
      });
      const session = new Session(DEFAULT_SETTINGS);
      const service = new VaultService(new VaultStore(db), session, { appVersion: APP_VERSION });
      await service.load();
      return { service, session };
    })();
    pending.catch(() => {
      pending = null;
    });
  }
  return pending;
}

/**
 * While the app hands control to a system picker (file chooser, "save as"),
 * Android pauses the Activity. Without this guard lockOnBackground would lock
 * the vault mid-upload and the picked file would be lost.
 */
let externalUntil = 0;
export function beginExternalActivity(ms = 120_000): void {
  externalUntil = Date.now() + ms;
}
export function endExternalActivity(): void {
  externalUntil = 0;
}
export function isExternalActivity(): boolean {
  return Date.now() < externalUntil;
}
