import { toBase64 } from '@pv/crypto';
import { beginExternalActivity } from './vaultClient.ts';

interface AndroidBridge {
  saveFile(name: string, mime: string, base64: string): void;
}

declare global {
  interface Window {
    PVAndroid?: AndroidBridge;
  }
}

/**
 * Saves bytes to a user-chosen location. Android WebView cannot download blob:
 * URLs, so the native bridge opens the system "save as" dialog instead.
 */
export function saveBytes(bytes: Uint8Array, name: string, mime: string): void {
  const type = mime || 'application/octet-stream';
  if (window.PVAndroid?.saveFile) {
    beginExternalActivity();
    window.PVAndroid.saveFile(name, type, toBase64(bytes));
    return;
  }
  const blob = new Blob([bytes], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  a.rel = 'noopener';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30_000);
}

export async function readFile(file: File): Promise<{ name: string; mime: string; bytes: Uint8Array }> {
  return { name: file.name, mime: file.type, bytes: new Uint8Array(await file.arrayBuffer()) };
}

/** Best-effort copy with delayed clear, so secrets do not linger on the clipboard. */
export async function copySecret(value: string, clearAfterSeconds: number): Promise<boolean> {
  let ok = false;
  try {
    await navigator.clipboard.writeText(value);
    ok = true;
  } catch {
    const ta = document.createElement('textarea');
    ta.value = value;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try {
      ok = document.execCommand('copy');
    } catch {
      ok = false;
    }
    ta.remove();
  }
  if (ok && clearAfterSeconds > 0) {
    setTimeout(() => {
      navigator.clipboard?.readText?.().then(
        (current) => {
          if (current === value) void navigator.clipboard.writeText('');
        },
        () => void navigator.clipboard?.writeText?.('').catch(() => undefined),
      );
    }, clearAfterSeconds * 1000);
  }
  return ok;
}
