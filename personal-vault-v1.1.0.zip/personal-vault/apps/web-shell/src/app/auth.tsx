import { useRef, useState } from 'react';
import { assessPassword } from '@pv/crypto';
import { Icon, Spinner } from './ui.tsx';
import { PASSWORD_ISSUES, errorText } from './i18n.ts';
import { beginExternalActivity, endExternalActivity } from './vaultClient.ts';
import { readFile } from './files.ts';

function PasswordInput({
  id,
  value,
  onChange,
  placeholder,
  autoFocus,
  autoComplete,
  invalid,
}: {
  id: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  autoFocus?: boolean;
  autoComplete: string;
  invalid?: boolean;
}) {
  const [shown, setShown] = useState(false);
  return (
    <div className={invalid ? 'pw-field is-invalid' : 'pw-field'}>
      <input
        id={id}
        type={shown ? 'text' : 'password'}
        value={value}
        dir="ltr"
        autoFocus={autoFocus}
        autoComplete={autoComplete}
        autoCapitalize="off"
        autoCorrect="off"
        spellCheck={false}
        placeholder={placeholder}
        aria-invalid={invalid || undefined}
        onChange={(e) => onChange(e.target.value)}
      />
      <button type="button" className="icon-btn" onClick={() => setShown((s) => !s)} aria-label={shown ? 'پنهان کردن رمز' : 'نمایش رمز'}>
        <Icon name={shown ? 'eyeOff' : 'eye'} size={18} />
      </button>
    </div>
  );
}

export function StrengthMeter({ password }: { password: string }) {
  if (!password) return null;
  const s = assessPassword(password);
  const labels = ['خیلی ضعیف', 'ضعیف', 'متوسط', 'خوب', 'قوی'];
  return (
    <div className="strength" data-score={s.score}>
      <div className="strength-bar" aria-hidden="true">
        {[0, 1, 2, 3].map((i) => (
          <span key={i} className={i < s.score ? 'on' : ''} />
        ))}
      </div>
      <span className="strength-label">{labels[s.score]}</span>
      {s.issues.length > 0 && <span className="strength-hint">نیاز دارد: {s.issues.map((i) => PASSWORD_ISSUES[i] ?? i).join('، ')}</span>}
    </div>
  );
}

function Brand() {
  return (
    <div className="auth-brand">
      <span className="brand-mark">
        <Icon name="lock" size={22} />
      </span>
      <span>Personal Vault</span>
    </div>
  );
}

function RestorePanel({ onRestore, onCancel }: { onRestore: (bytes: Uint8Array, password: string) => Promise<void>; onCancel: () => void }) {
  const [file, setFile] = useState<{ name: string; bytes: Uint8Array } | null>(null);
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const input = useRef<HTMLInputElement>(null);
  return (
    <form
      className="auth-form"
      onSubmit={async (e) => {
        e.preventDefault();
        if (!file || !password) return;
        setBusy(true);
        setError('');
        try {
          await onRestore(file.bytes, password);
        } catch (err) {
          setError(errorText(err));
        } finally {
          setBusy(false);
        }
      }}
    >
      <h2 className="auth-sub">بازیابی از فایل پشتیبان</h2>
      <input
        ref={input}
        type="file"
        hidden
        accept=".pvbackup,.json,application/json,application/octet-stream"
        onChange={async (e) => {
          endExternalActivity();
          const f = e.target.files?.[0];
          e.target.value = '';
          if (f) {
            const r = await readFile(f);
            setFile({ name: r.name, bytes: r.bytes });
          }
        }}
      />
      <button
        type="button"
        className="drop"
        onClick={() => {
          beginExternalActivity();
          input.current?.click();
        }}
      >
        <Icon name="upload" />
        <span>{file ? file.name : 'انتخاب فایل پشتیبان'}</span>
      </button>
      <label htmlFor="restore-pw">رمز عبوری که هنگام ساخت پشتیبان فعال بود</label>
      <PasswordInput id="restore-pw" value={password} onChange={setPassword} autoComplete="current-password" />
      {error && <p className="form-error" role="alert">{error}</p>}
      <button className="btn btn-primary btn-block" disabled={!file || !password || busy}>
        {busy ? <><Spinner /> در حال بررسی و بازیابی…</> : 'بازیابی Vault'}
      </button>
      <button type="button" className="btn btn-ghost btn-block" onClick={onCancel} disabled={busy}>
        بازگشت
      </button>
    </form>
  );
}

export function SetupScreen({
  onCreate,
  onRestore,
}: {
  onCreate: (password: string) => Promise<void>;
  onRestore: (bytes: Uint8Array, password: string) => Promise<void>;
}) {
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [restoring, setRestoring] = useState(false);
  const strength = assessPassword(password);
  const mismatch = confirm.length > 0 && confirm !== password;
  const canSubmit = strength.acceptable && password === confirm && !busy;

  return (
    <main className="auth">
      <section className="auth-card">
        <Brand />
        {restoring ? (
          <RestorePanel onRestore={onRestore} onCancel={() => setRestoring(false)} />
        ) : (
          <>
            <h1>
              یک رمز، <em>برای همه‌چیز.</em>
            </h1>
            <p className="auth-lead">
              رمز اصلی کلید رمزنگاری Vault را می‌سازد و هیچ‌جا ذخیره نمی‌شود. اگر فراموشش کنی، بدون فایل پشتیبان راه بازگشتی نیست.
            </p>
            <form
              className="auth-form"
              onSubmit={async (e) => {
                e.preventDefault();
                if (!canSubmit) return;
                setBusy(true);
                setError('');
                try {
                  await onCreate(password);
                } catch (err) {
                  setError(errorText(err));
                  setBusy(false);
                }
              }}
            >
              <label htmlFor="new-pw">رمز عبور اصلی</label>
              <PasswordInput id="new-pw" value={password} onChange={setPassword} autoFocus autoComplete="new-password" />
              <StrengthMeter password={password} />
              <label htmlFor="confirm-pw">تکرار رمز عبور</label>
              <PasswordInput id="confirm-pw" value={confirm} onChange={setConfirm} autoComplete="new-password" invalid={mismatch} />
              {mismatch && <p className="form-error">رمزها یکی نیستند.</p>}
              {error && <p className="form-error" role="alert">{error}</p>}
              <button className="btn btn-primary btn-block" disabled={!canSubmit}>
                {busy ? <><Spinner /> ساخت کلیدها…</> : 'ساخت Vault'}
              </button>
              <button type="button" className="btn btn-ghost btn-block" onClick={() => setRestoring(true)}>
                <Icon name="restore" size={18} /> بازیابی از پشتیبان
              </button>
            </form>
          </>
        )}
      </section>
      <p className="auth-foot">
        <Icon name="shield" size={16} /> AES-GCM ۲۵۶ · PBKDF2 با ۶۰۰٬۰۰۰ تکرار · کاملاً آفلاین
      </p>
    </main>
  );
}

export function LockScreen({
  onUnlock,
  onRestore,
  reason,
}: {
  onUnlock: (password: string) => Promise<void>;
  onRestore: (bytes: Uint8Array, password: string) => Promise<void>;
  reason: string | null;
}) {
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [shake, setShake] = useState(0);
  const [restoring, setRestoring] = useState(false);

  return (
    <main className="auth">
      <section className="auth-card">
        <Brand />
        {restoring ? (
          <RestorePanel onRestore={onRestore} onCancel={() => setRestoring(false)} />
        ) : (
          <>
            <h1>
              خوش برگشتی. <em>Vault قفل است.</em>
            </h1>
            {reason && <p className="auth-reason">{reason}</p>}
            <form
              key={shake}
              className={shake ? 'auth-form shake' : 'auth-form'}
              onSubmit={async (e) => {
                e.preventDefault();
                if (!password || busy) return;
                setBusy(true);
                setError('');
                try {
                  await onUnlock(password);
                } catch (err) {
                  setError(errorText(err));
                  setShake((n) => n + 1);
                  setBusy(false);
                }
              }}
            >
              <label htmlFor="unlock-pw">رمز عبور اصلی</label>
              <PasswordInput id="unlock-pw" value={password} onChange={setPassword} autoFocus autoComplete="current-password" invalid={Boolean(error)} />
              {error && <p className="form-error" role="alert">{error}</p>}
              <button className="btn btn-primary btn-block" disabled={!password || busy}>
                {busy ? <><Spinner /> رمزگشایی…</> : <>باز کردن Vault</>}
              </button>
            </form>
            <button type="button" className="btn btn-ghost btn-block" onClick={() => setRestoring(true)}>
              <Icon name="restore" size={18} /> بازیابی از پشتیبان
            </button>
          </>
        )}
      </section>
      <p className="auth-foot">
        <Icon name="shield" size={16} /> داده‌ها فقط روی همین دستگاه، رمزنگاری‌شده
      </p>
    </main>
  );
}

export { PasswordInput };
