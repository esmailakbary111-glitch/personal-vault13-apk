import { useEffect, useRef, useState } from 'react';
import {
  ITEM_TYPES,
  formatBytes,
  previewKindOf,
  type AttachmentMeta,
  type CustomField,
  type ItemDraft,
  type ItemType,
  type VaultItem,
  type VaultService,
} from '@pv/core';
import { randomId } from '@pv/crypto';
import { Icon, Sheet, Spinner } from './ui.tsx';
import { TYPE_LABELS, dateLabel, errorText } from './i18n.ts';
import { copySecret, readFile, saveBytes } from './files.ts';
import { beginExternalActivity, endExternalActivity } from './vaultClient.ts';

type Pending = { key: string; name: string; mime: string; bytes: Uint8Array };

export interface EditorProps {
  service: VaultService;
  itemId: string | null; // null = new
  initialType?: ItemType;
  clipboardSeconds: number;
  onClose: () => void;
  onChanged: (message?: string) => void;
  onError: (text: string) => void;
  onToast: (text: string) => void;
  confirm: (opts: { title: string; body: string; confirmLabel: string; danger?: boolean; onConfirm: () => Promise<void> | void }) => void;
}

const emptyDraft = (type: ItemType = 'note'): ItemDraft => ({
  title: '',
  type,
  category: '',
  tags: [],
  body: '',
  fields: type === 'credential' ? [{ id: randomId(), label: 'نام کاربری', value: '', secret: false }, { id: randomId(), label: 'رمز عبور', value: '', secret: true }] : [],
  url: '',
  favorite: false,
});

function FieldRow({
  field,
  onChange,
  onRemove,
  onCopy,
}: {
  field: CustomField;
  onChange: (f: CustomField) => void;
  onRemove: () => void;
  onCopy: () => void;
}) {
  const [reveal, setReveal] = useState(false);
  return (
    <div className="field-row">
      <input className="field-label" value={field.label} placeholder="برچسب" aria-label="برچسب فیلد" onChange={(e) => onChange({ ...field, label: e.target.value })} />
      <div className="field-value">
        <input
          value={field.value}
          type={field.secret && !reveal ? 'password' : 'text'}
          dir="auto"
          autoComplete="off"
          placeholder="مقدار"
          aria-label={`مقدار ${field.label || 'فیلد'}`}
          onChange={(e) => onChange({ ...field, value: e.target.value })}
        />
        {field.secret && (
          <button type="button" className="icon-btn sm" onClick={() => setReveal((r) => !r)} aria-label={reveal ? 'پنهان' : 'نمایش'}>
            <Icon name={reveal ? 'eyeOff' : 'eye'} size={16} />
          </button>
        )}
        <button type="button" className="icon-btn sm" onClick={onCopy} aria-label="کپی" disabled={!field.value}>
          <Icon name="copy" size={16} />
        </button>
      </div>
      <div className="field-tools">
        <label className="chip-check">
          <input type="checkbox" checked={field.secret} onChange={(e) => onChange({ ...field, secret: e.target.checked })} />
          <span>محرمانه</span>
        </label>
        <button type="button" className="icon-btn sm danger" onClick={onRemove} aria-label="حذف فیلد">
          <Icon name="trash" size={16} />
        </button>
      </div>
    </div>
  );
}

export function ItemEditor(props: EditorProps) {
  const { service, itemId, onClose, onChanged, onError, onToast } = props;
  const [loading, setLoading] = useState(itemId !== null);
  const [item, setItem] = useState<VaultItem | null>(null);
  const [draft, setDraft] = useState<ItemDraft>(() => emptyDraft(props.initialType));
  const [tagText, setTagText] = useState('');
  const [pending, setPending] = useState<Pending[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  const [preview, setPreview] = useState<{ url: string; name: string } | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const isTrash = item?.deletedAt != null;
  const cb = useRef({ onError, onClose });
  cb.current = { onError, onClose };

  useEffect(() => {
    if (itemId === null) return;
    let alive = true;
    service
      .getItem(itemId)
      .then((it) => {
        if (!alive) return;
        setItem(it);
        setDraft({
          title: it.title,
          type: it.type,
          category: it.category ?? '',
          tags: it.tags,
          body: it.body,
          fields: it.fields,
          url: it.url ?? '',
          favorite: it.favorite,
        });
        setTagText(it.tags.join('، '));
        setLoading(false);
      })
      .catch((e) => {
        if (!alive) return;
        cb.current.onError(errorText(e));
        cb.current.onClose();
      });
    return () => {
      alive = false;
    };
  }, [itemId, service]);

  useEffect(() => () => {
    if (preview) URL.revokeObjectURL(preview.url);
  }, [preview]);

  const set = <K extends keyof ItemDraft>(k: K, v: ItemDraft[K]) => setDraft((d) => ({ ...d, [k]: v }));
  const fields = draft.fields ?? [];
  const parsedTags = () => tagText.split(/[,،]/).map((t) => t.trim()).filter(Boolean);

  const run = async (label: string, fn: () => Promise<void>) => {
    setBusy(label);
    try {
      await fn();
    } catch (e) {
      onError(errorText(e));
    } finally {
      setBusy(null);
    }
  };

  const save = () =>
    run('save', async () => {
      const payload: ItemDraft = {
        ...draft,
        title: draft.title.trim(),
        category: draft.category?.trim() || null,
        url: draft.url?.trim() || null,
        tags: parsedTags(),
        fields: fields.filter((f) => f.label.trim() || f.value),
      };
      if (itemId === null) {
        await service.createItem(payload, pending.map(({ name, mime, bytes }) => ({ name, mime, bytes })));
        onChanged('مورد جدید رمزنگاری و ذخیره شد');
      } else {
        await service.updateItem(itemId, payload);
        if (pending.length) await service.attachFiles(itemId, pending.map(({ name, mime, bytes }) => ({ name, mime, bytes })));
        onChanged('تغییرات ذخیره شد');
      }
      onClose();
    });

  const addFiles = async (list: FileList | null) => {
    endExternalActivity();
    if (!list?.length) return;
    const next: Pending[] = [];
    for (const f of Array.from(list)) {
      if (f.size > 25 * 1024 * 1024) {
        onError(`«${f.name}» بیشتر از ۲۵ مگابایت است.`);
        continue;
      }
      const r = await readFile(f);
      next.push({ key: randomId(), ...r });
    }
    setPending((p) => [...p, ...next]);
  };

  const download = (a: AttachmentMeta) =>
    run(`dl-${a.blobId}`, async () => {
      if (!itemId) return;
      const file = await service.readAttachment(itemId, a.blobId);
      saveBytes(file.bytes, file.name, file.mime);
    });

  const showImage = (a: AttachmentMeta) =>
    run(`pv-${a.blobId}`, async () => {
      if (!itemId) return;
      const file = await service.readAttachment(itemId, a.blobId);
      const url = URL.createObjectURL(new Blob([file.bytes], { type: file.mime }));
      setPreview({ url, name: file.name });
    });

  const removeAttachment = (a: AttachmentMeta) =>
    props.confirm({
      title: 'حذف پیوست',
      body: `«${a.name}» برای همیشه حذف می‌شود.`,
      confirmLabel: 'حذف پیوست',
      danger: true,
      onConfirm: async () => {
        if (!itemId) return;
        try {
          const it = await service.removeAttachment(itemId, a.blobId);
          setItem(it);
          onChanged('پیوست حذف شد');
        } catch (e) {
          onError(errorText(e));
        }
      },
    });

  const title = itemId === null ? 'مورد جدید' : isTrash ? 'در سطل زباله' : 'ویرایش مورد';

  const footer = loading ? null : isTrash ? (
    <>
      <button
        type="button"
        className="btn btn-danger"
        disabled={!!busy}
        onClick={() =>
          props.confirm({
            title: 'حذف همیشگی',
            body: 'این مورد و همه پیوست‌هایش برای همیشه پاک می‌شود و قابل بازگشت نیست.',
            confirmLabel: 'حذف همیشگی',
            danger: true,
            onConfirm: async () => {
              try {
                await service.deleteForever(itemId as string);
                onChanged('برای همیشه حذف شد');
                onClose();
              } catch (e) {
                onError(errorText(e));
              }
            },
          })
        }
      >
        حذف همیشگی
      </button>
      <button
        type="button"
        className="btn btn-primary"
        disabled={!!busy}
        onClick={() =>
          run('restore', async () => {
            await service.restoreFromTrash(itemId as string);
            onChanged('به Vault برگشت');
            onClose();
          })
        }
      >
        <Icon name="restore" size={18} /> بازگرداندن
      </button>
    </>
  ) : (
    <>
      {itemId !== null && (
        <div className="foot-extra">
          <button
            type="button"
            className="icon-btn"
            aria-label="انتقال به سطل زباله"
            title="انتقال به سطل زباله"
            disabled={!!busy}
            onClick={() =>
              run('trash', async () => {
                await service.moveToTrash(itemId);
                onChanged('به سطل زباله منتقل شد');
                onClose();
              })
            }
          >
            <Icon name="trash" />
          </button>
          <button
            type="button"
            className="icon-btn"
            aria-label="تکثیر"
            title="تکثیر"
            disabled={!!busy}
            onClick={() =>
              run('dup', async () => {
                await service.duplicateItem(itemId);
                onChanged('یک نسخه تکراری ساخته شد');
                onClose();
              })
            }
          >
            <Icon name="duplicate" />
          </button>
        </div>
      )}
      <button type="button" className="btn" onClick={onClose} disabled={!!busy}>
        انصراف
      </button>
      <button type="button" className="btn btn-primary" onClick={save} disabled={!!busy || !draft.title.trim()}>
        {busy === 'save' ? <><Spinner /> رمزنگاری…</> : 'ذخیره'}
      </button>
    </>
  );

  return (
    <Sheet title={title} eyebrow={item ? `آخرین تغییر ${dateLabel(item.updatedAt)}` : undefined} onClose={onClose} footer={footer} wide>
      {loading ? (
        <div className="editor-skeleton" aria-busy="true">
          <span />
          <span />
          <span className="tall" />
        </div>
      ) : (
        <fieldset className="editor" disabled={isTrash}>
          <div className="title-row">
            <input
              className="title-input"
              data-autofocus
              value={draft.title}
              onChange={(e) => set('title', e.target.value)}
              placeholder="عنوان"
              aria-label="عنوان"
              maxLength={200}
            />
            <button
              type="button"
              className={draft.favorite ? 'icon-btn fav on' : 'icon-btn fav'}
              aria-pressed={!!draft.favorite}
              aria-label="نشانه‌گذاری به‌عنوان علاقه‌مندی"
              onClick={() => set('favorite', !draft.favorite)}
            >
              <Icon name="star" />
            </button>
          </div>

          <div className="type-picker" role="radiogroup" aria-label="نوع">
            {ITEM_TYPES.map((t) => (
              <button
                type="button"
                key={t}
                role="radio"
                aria-checked={draft.type === t}
                className={draft.type === t ? 'type-chip on' : 'type-chip'}
                onClick={() => set('type', t)}
              >
                {TYPE_LABELS[t]}
              </button>
            ))}
          </div>

          <div className="grid-2">
            <label>
              <span>دسته‌بندی</span>
              <input value={draft.category ?? ''} onChange={(e) => set('category', e.target.value)} placeholder="مثلاً سفر" maxLength={40} />
            </label>
            <label>
              <span>برچسب‌ها</span>
              <input value={tagText} onChange={(e) => setTagText(e.target.value)} placeholder="با ، جدا کن" />
            </label>
          </div>

          {(draft.type === 'link' || draft.url) && (
            <label>
              <span>آدرس</span>
              <input value={draft.url ?? ''} dir="ltr" inputMode="url" onChange={(e) => set('url', e.target.value)} placeholder="https://" />
            </label>
          )}

          <label>
            <span>متن</span>
            <textarea rows={6} value={draft.body ?? ''} dir="auto" onChange={(e) => set('body', e.target.value)} placeholder="هرچه می‌خواهی امن بماند…" />
          </label>

          <section className="block">
            <div className="block-head">
              <h3>فیلدها</h3>
              <button type="button" className="btn btn-ghost sm" onClick={() => set('fields', [...fields, { id: randomId(), label: '', value: '', secret: false }])}>
                <Icon name="plus" size={16} /> فیلد
              </button>
            </div>
            {fields.length === 0 && <p className="hint">برای شماره کارت، نام کاربری یا هر مقدار ساختاریافته یک فیلد اضافه کن. فیلدهای محرمانه هیچ‌وقت در پیش‌نمایش دیده نمی‌شوند.</p>}
            {fields.map((f, i) => (
              <FieldRow
                key={f.id}
                field={f}
                onChange={(nf) => set('fields', fields.map((x, j) => (j === i ? nf : x)))}
                onRemove={() => set('fields', fields.filter((_, j) => j !== i))}
                onCopy={async () => {
                  const ok = await copySecret(f.value, props.clipboardSeconds);
                  onToast(ok ? (f.secret && props.clipboardSeconds > 0 ? `کپی شد، پس از ${props.clipboardSeconds} ثانیه پاک می‌شود` : 'کپی شد') : 'کپی ممکن نشد');
                }}
              />
            ))}
          </section>

          <section className="block">
            <div className="block-head">
              <h3>پیوست‌ها</h3>
              <button
                type="button"
                className="btn btn-ghost sm"
                onClick={() => {
                  beginExternalActivity();
                  fileInput.current?.click();
                }}
              >
                <Icon name="clip" size={16} /> افزودن فایل
              </button>
              <input ref={fileInput} type="file" multiple hidden onChange={(e) => { void addFiles(e.target.files); e.target.value = ''; }} />
            </div>
            {(item?.attachments.length ?? 0) + pending.length === 0 && <p className="hint">تصویر، PDF یا هر فایلی تا ۲۵ مگابایت. فایل‌ها تکه‌تکه رمزنگاری می‌شوند.</p>}
            <ul className="files">
              {item?.attachments.map((a) => {
                const kind = previewKindOf(a.mime, a.name);
                return (
                  <li key={a.blobId}>
                    <Icon name={kind === 'image' ? 'image' : 'file'} />
                    <div className="file-meta">
                      <strong dir="auto">{a.name}</strong>
                      <span>{formatBytes(a.size)}</span>
                    </div>
                    {kind === 'image' && (
                      <button type="button" className="icon-btn sm" onClick={() => showImage(a)} aria-label="نمایش" disabled={busy === `pv-${a.blobId}`}>
                        {busy === `pv-${a.blobId}` ? <Spinner /> : <Icon name="eye" size={16} />}
                      </button>
                    )}
                    <button type="button" className="icon-btn sm" onClick={() => download(a)} aria-label="ذخیره فایل" disabled={busy === `dl-${a.blobId}`}>
                      {busy === `dl-${a.blobId}` ? <Spinner /> : <Icon name="download" size={16} />}
                    </button>
                    {!isTrash && (
                      <button type="button" className="icon-btn sm danger" onClick={() => removeAttachment(a)} aria-label="حذف پیوست">
                        <Icon name="trash" size={16} />
                      </button>
                    )}
                  </li>
                );
              })}
              {pending.map((p) => (
                <li key={p.key} className="pending">
                  <Icon name="clip" />
                  <div className="file-meta">
                    <strong dir="auto">{p.name}</strong>
                    <span>{formatBytes(p.bytes.byteLength)} · بعد از ذخیره رمزنگاری می‌شود</span>
                  </div>
                  <button type="button" className="icon-btn sm danger" onClick={() => setPending((x) => x.filter((y) => y.key !== p.key))} aria-label="برداشتن">
                    <Icon name="x" size={16} />
                  </button>
                </li>
              ))}
            </ul>
          </section>
        </fieldset>
      )}
      {preview && (
        <div className="lightbox" onClick={() => setPreview(null)} role="presentation">
          <img src={preview.url} alt={preview.name} />
        </div>
      )}
    </Sheet>
  );
}
