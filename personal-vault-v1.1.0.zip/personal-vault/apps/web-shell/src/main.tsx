import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import '@pv/ui/tokens.css';
import './styles.css';
import {
  ITEM_TYPES,
  type ItemSummary,
  type ItemType,
  type Settings,
  type SortKey,
  type VaultStatus,
} from '@pv/core';
import { endExternalActivity, getVaultClient, isExternalActivity, type VaultClient } from './app/vaultClient.ts';
import { ConfirmDialog, Icon, Spinner, Toasts, TYPE_ICONS, type ConfirmState, type ToastMsg } from './app/ui.tsx';
import { LockScreen, SetupScreen } from './app/auth.tsx';
import { ItemEditor } from './app/editor.tsx';
import { SettingsView } from './app/settings.tsx';
import { TYPE_LABELS, errorText, fa, relativeTime, todayLabel } from './app/i18n.ts';

type View = 'home' | 'items' | 'favorites' | 'trash' | 'settings';
type Phase = { kind: 'boot' } | { kind: 'fatal'; message: string } | { kind: 'setup' } | { kind: 'locked'; reason: string | null } | { kind: 'open' };

const LOCK_REASONS: Record<string, string> = {
  timeout: 'به‌خاطر بی‌فعالیتی قفل شد.',
  background: 'با خروج از برنامه قفل شد.',
};

function useTheme(theme: Settings['theme'] | undefined) {
  useEffect(() => {
    const root = document.documentElement;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const apply = () => {
      const mode = theme === 'light' || theme === 'dark' ? theme : mq.matches ? 'dark' : 'light';
      root.dataset.theme = mode;
      document.querySelector('meta[name="theme-color"]')?.setAttribute('content', mode === 'dark' ? '#101513' : '#f3f5f1');
    };
    apply();
    mq.addEventListener?.('change', apply);
    return () => mq.removeEventListener?.('change', apply);
  }, [theme]);
}

function ItemRow({ item, showPreview, onOpen, index }: { item: ItemSummary; showPreview: boolean; onOpen: () => void; index: number }) {
  return (
    <li className="row" style={{ '--i': Math.min(index, 8) } as React.CSSProperties}>
      <button type="button" className="row-btn" onClick={onOpen}>
        <span className={`row-icon t-${item.type}`}>
          <Icon name={TYPE_ICONS[item.type] ?? 'file'} size={19} />
        </span>
        <span className="row-main">
          <span className="row-title">
            <strong dir="auto">{item.title}</strong>
            {item.favorite && <Icon name="star" size={14} className="fav-mark" />}
          </span>
          <span className="row-sub">
            {TYPE_LABELS[item.type]}
            {item.category && <> · {item.category}</>}
            {item.attachmentCount > 0 && (
              <>
                {' '}· <Icon name="clip" size={12} /> {fa(item.attachmentCount)}
              </>
            )}
          </span>
          {showPreview && item.preview && <span className="row-preview" dir="auto">{item.preview}</span>}
        </span>
        <span className="row-time">{relativeTime(item.deletedAt ?? item.updatedAt)}</span>
      </button>
    </li>
  );
}

function Empty({ view, onCreate, searching }: { view: View; onCreate: () => void; searching: boolean }) {
  if (searching)
    return (
      <div className="empty">
        <Icon name="search" size={28} />
        <h3>چیزی پیدا نشد</h3>
        <p>کلمه دیگری امتحان کن یا فیلتر نوع را بردار.</p>
      </div>
    );
  if (view === 'trash')
    return (
      <div className="empty">
        <Icon name="trash" size={28} />
        <h3>سطل زباله خالی است</h3>
        <p>موارد حذف‌شده تا وقتی خودت پاکشان نکنی اینجا می‌مانند.</p>
      </div>
    );
  if (view === 'favorites')
    return (
      <div className="empty">
        <Icon name="star" size={28} />
        <h3>هنوز علاقه‌مندی نداری</h3>
        <p>ستاره کنار عنوان هر مورد را بزن تا اینجا بیاید.</p>
      </div>
    );
  return (
    <div className="empty">
      <Icon name="lock" size={28} />
      <h3>Vault خالی است</h3>
      <p>اولین یادداشت، مدرک یا رمز را اضافه کن. همه‌چیز قبل از ذخیره روی همین دستگاه رمزنگاری می‌شود.</p>
      <button type="button" className="btn btn-primary" onClick={onCreate}>
        <Icon name="plus" size={18} /> اولین مورد
      </button>
    </div>
  );
}

function App() {
  const [client, setClient] = useState<VaultClient | null>(null);
  const [phase, setPhase] = useState<Phase>({ kind: 'boot' });
  const [settings, setSettings] = useState<Settings | null>(null);
  const [status, setStatus] = useState<VaultStatus | null>(null);
  const [rev, setRev] = useState(0);
  const [view, setView] = useState<View>('home');
  const [query, setQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<ItemType | null>(null);
  const [sort, setSort] = useState<SortKey>('updated_desc');
  const [editor, setEditor] = useState<{ id: string | null; type?: ItemType } | null>(null);
  const [toasts, setToasts] = useState<ToastMsg[]>([]);
  const [confirm, setConfirm] = useState<ConfirmState | null>(null);
  const toastId = useRef(0);
  const searchRef = useRef<HTMLInputElement>(null);

  useTheme(settings?.theme);

  const toast = useCallback((text: string, tone: ToastMsg['tone'] = 'ok') => {
    const id = ++toastId.current;
    setToasts((t) => [...t.slice(-2), { id, text, tone }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), tone === 'error' ? 4200 : 2600);
  }, []);
  const toastError = useCallback((text: string) => toast(text, 'error'), [toast]);

  // boot: open IndexedDB and the real VaultService
  useEffect(() => {
    getVaultClient()
      .then((c) => {
        setClient(c);
        setSettings(c.service.getSettings());
        const s = c.service.status();
        setStatus(s);
        setPhase(s.exists ? { kind: 'locked', reason: null } : { kind: 'setup' });
      })
      .catch((e) => setPhase({ kind: 'fatal', message: errorText(e) }));
  }, []);

  // session events: auto-lock, background lock
  useEffect(() => {
    if (!client) return;
    const off = client.session.subscribe((event) => {
      setStatus(client.service.status());
      if (!event.unlocked) {
        setEditor(null);
        setConfirm(null);
        setQuery('');
        setPhase({ kind: 'locked', reason: event.reason ? LOCK_REASONS[event.reason] ?? null : null });
      }
    });
    const hidden = () => {
      if (!isExternalActivity()) client.session.handleAppHidden();
    };
    const visible = () => {
      client.session.handleAppVisible();
      // A cancelled picker never fires "change"; drop the guard shortly after return.
      setTimeout(endExternalActivity, 1500);
    };
    const saved = (e: Event) => {
      endExternalActivity();
      if ((e as CustomEvent<boolean>).detail === false) toast('فایل ذخیره نشد', 'error');
    };
    const onVis = () => (document.visibilityState === 'hidden' ? hidden() : visible());
    let last = 0;
    const touch = () => {
      const now = Date.now();
      if (now - last > 5000) {
        last = now;
        client.session.touch();
      }
    };
    document.addEventListener('visibilitychange', onVis);
    window.addEventListener('pv:hidden', hidden);
    window.addEventListener('pv:visible', visible);
    window.addEventListener('pv:saved', saved);
    window.addEventListener('pointerdown', touch, { passive: true });
    window.addEventListener('keydown', touch);
    return () => {
      off();
      document.removeEventListener('visibilitychange', onVis);
      window.removeEventListener('pv:hidden', hidden);
      window.removeEventListener('pv:visible', visible);
      window.removeEventListener('pv:saved', saved);
      window.removeEventListener('pointerdown', touch);
      window.removeEventListener('keydown', touch);
    };
  }, [client, toast]);

  // Ctrl/Cmd+K focuses search
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k' && phase.kind === 'open') {
        e.preventDefault();
        if (view === 'settings' || view === 'home') setView('items');
        setTimeout(() => searchRef.current?.focus(), 0);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [phase.kind, view]);

  const refresh = useCallback(
    (message?: string) => {
      if (client) setStatus(client.service.status());
      setRev((r) => r + 1);
      if (message) toast(message);
    },
    [client, toast],
  );

  const open = phase.kind === 'open' && client && client.session.isUnlocked;

  const list = useMemo(() => {
    if (!open || !client) return [] as ItemSummary[];
    void rev;
    const base = {
      text: query || undefined,
      types: typeFilter ? [typeFilter] : undefined,
      sort,
    };
    if (view === 'trash') return client.service.search({ ...base, scope: 'trash' });
    if (view === 'favorites') return client.service.search({ ...base, favoritesOnly: true });
    if (view === 'home') return client.service.search({ ...base }).slice(0, query || typeFilter ? 50 : 6);
    return client.service.search(base);
  }, [open, client, rev, query, typeFilter, sort, view]);

  const facets = useMemo(() => {
    void rev;
    return open && client ? client.service.facets() : null;
  }, [open, client, rev]);
  const favCount = useMemo(() => {
    void rev;
    return open && client ? client.service.search({ favoritesOnly: true }).length : 0;
  }, [open, client, rev]);

  if (phase.kind === 'boot')
    return (
      <main className="boot">
        <Spinner label="در حال آماده‌سازی" />
      </main>
    );
  if (phase.kind === 'fatal')
    return (
      <main className="boot">
        <Icon name="alert" size={28} />
        <p>{phase.message}</p>
        <button type="button" className="btn" onClick={() => window.location.reload()}>تلاش دوباره</button>
      </main>
    );
  if (!client || !settings || !status) return null;

  const onRestore = async (bytes: Uint8Array, password: string) => {
    await client.service.restoreBackupFile(bytes, password);
    setStatus(client.service.status());
    setSettings(client.service.getSettings());
    setPhase({ kind: 'open' });
    setView('home');
    refresh('Vault از پشتیبان بازیابی شد');
  };

  if (phase.kind === 'setup')
    return (
      <>
        <SetupScreen
          onRestore={onRestore}
          onCreate={async (password) => {
            await client.service.createVault(password);
            setStatus(client.service.status());
            setPhase({ kind: 'open' });
            refresh('Vault ساخته شد');
          }}
        />
        <Toasts items={toasts} onDismiss={(id) => setToasts((t) => t.filter((x) => x.id !== id))} />
      </>
    );

  if (phase.kind === 'locked' || !open)
    return (
      <>
        <LockScreen
          reason={phase.kind === 'locked' ? phase.reason : null}
          onRestore={onRestore}
          onUnlock={async (password) => {
            await client.service.unlock(password);
            setStatus(client.service.status());
            setPhase({ kind: 'open' });
            setView('home');
            refresh();
          }}
        />
        <Toasts items={toasts} onDismiss={(id) => setToasts((t) => t.filter((x) => x.id !== id))} />
      </>
    );

  const lock = () => client.service.lock();
  const newItem = (type?: ItemType) => setEditor({ id: null, type });
  const titles: Record<View, string> = {
    home: 'خانه',
    items: 'همه موارد',
    favorites: 'علاقه‌مندی‌ها',
    trash: 'سطل زباله',
    settings: 'تنظیمات',
  };
  const nav: { v: View; icon: string; label: string; count?: number }[] = [
    { v: 'home', icon: 'home', label: 'خانه' },
    { v: 'items', icon: 'list', label: 'همه', count: status.itemCount },
    { v: 'favorites', icon: 'star', label: 'علاقه‌مندی', count: favCount },
    { v: 'trash', icon: 'trash', label: 'سطل', count: status.trashCount },
    { v: 'settings', icon: 'settings', label: 'تنظیمات' },
  ];
  const go = (v: View) => {
    setView(v);
    setTypeFilter(null);
    if (v !== 'items') setQuery('');
    window.scrollTo({ top: 0 });
  };
  const usedTypes = ITEM_TYPES.filter((t) => (facets?.types[t] ?? 0) > 0);

  return (
    <div className="shell">
      <aside className="rail" aria-label="ناوبری">
        <div className="rail-brand">
          <span className="brand-mark"><Icon name="lock" size={18} /></span>
          <span>Personal Vault</span>
        </div>
        <button type="button" className="btn btn-primary btn-block rail-new" onClick={() => newItem()}>
          <Icon name="plus" size={18} /> مورد جدید
        </button>
        <nav>
          {nav.map((n) => (
            <button type="button" key={n.v} className={view === n.v ? 'rail-link on' : 'rail-link'} aria-current={view === n.v ? 'page' : undefined} onClick={() => go(n.v)}>
              <Icon name={n.icon} size={19} />
              <span>{n.v === 'items' ? 'همه موارد' : n.v === 'favorites' ? 'علاقه‌مندی‌ها' : n.v === 'trash' ? 'سطل زباله' : n.label}</span>
              {n.count ? <em>{fa(n.count)}</em> : null}
            </button>
          ))}
        </nav>
        <button type="button" className="rail-link rail-lock" onClick={lock}>
          <Icon name="lock" size={19} />
          <span>قفل کردن</span>
        </button>
      </aside>

      <main className="main" id="main">
        <header className="topbar">
          <div className="topbar-title">
            <span className="eyebrow">{view === 'home' ? todayLabel() : `${fa(list.length)} مورد`}</span>
            <h1>{titles[view]}</h1>
          </div>
          <div className="topbar-actions">
            <button
              type="button"
              className="icon-btn"
              aria-label="تغییر پوسته"
              onClick={() => {
                const current = document.documentElement.dataset.theme;
                void client.service.updateSettings({ theme: current === 'dark' ? 'light' : 'dark' }).then(setSettings);
              }}
            >
              <Icon name={document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon'} />
            </button>
            <button type="button" className="icon-btn lock-quick" aria-label="قفل کردن" onClick={lock}>
              <Icon name="lock" />
            </button>
          </div>
        </header>

        {view === 'settings' ? (
          <SettingsView
            service={client.service}
            settings={settings}
            status={status}
            onSettings={(patch) => {
              void client.service.updateSettings(patch).then(setSettings, (e) => toastError(errorText(e)));
            }}
            onLock={lock}
            onToast={(t) => toast(t)}
            onError={toastError}
            onRestored={() => {
              setStatus(client.service.status());
              setView('home');
              refresh('Vault از پشتیبان بازیابی شد');
            }}
          />
        ) : (
          <>
            {view === 'home' && (
              <section className="hero">
                <div className="hero-copy">
                  <h2>
                    {status.itemCount === 0 ? 'آماده برای اولین مورد.' : <>{fa(status.itemCount)} مورد، همه رمزنگاری‌شده.</>}
                  </h2>
                  <p>
                    <Icon name="shield" size={16} /> کلید فقط تا زمان قفل در حافظه است
                    {settings.autoLockMs > 0 && <> · قفل خودکار پس از {fa(Math.round(settings.autoLockMs / 60000))} دقیقه</>}
                  </p>
                </div>
                <div className="quick">
                  {(['note', 'credential', 'personal', 'file'] as ItemType[]).map((t) => (
                    <button type="button" key={t} className="quick-btn" onClick={() => newItem(t)}>
                      <span className={`row-icon t-${t}`}><Icon name={TYPE_ICONS[t] ?? 'file'} size={18} /></span>
                      <span>{TYPE_LABELS[t]}</span>
                    </button>
                  ))}
                </div>
              </section>
            )}

            <div className="search">
              <Icon name="search" size={18} />
              <input
                ref={searchRef}
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={view === 'trash' ? 'جستجو در سطل زباله' : 'جستجوی عنوان، برچسب، دسته…'}
                aria-label="جستجو"
                enterKeyHint="search"
              />
              {query ? (
                <button type="button" className="icon-btn sm" aria-label="پاک کردن جستجو" onClick={() => setQuery('')}>
                  <Icon name="x" size={16} />
                </button>
              ) : (
                <kbd dir="ltr">Ctrl K</kbd>
              )}
            </div>

            {usedTypes.length > 1 && view !== 'trash' && (
              <div className="filters" role="toolbar" aria-label="فیلتر نوع">
                <button type="button" className={typeFilter === null ? 'type-chip on' : 'type-chip'} onClick={() => setTypeFilter(null)}>همه</button>
                {usedTypes.map((t) => (
                  <button type="button" key={t} className={typeFilter === t ? 'type-chip on' : 'type-chip'} onClick={() => setTypeFilter(typeFilter === t ? null : t)}>
                    {TYPE_LABELS[t]} <em>{fa(facets?.types[t] ?? 0)}</em>
                  </button>
                ))}
              </div>
            )}

            <div className="list-head">
              <h2>{view === 'home' ? (query || typeFilter ? 'نتایج' : 'اخیر') : titles[view]}</h2>
              <div className="list-tools">
                {view !== 'home' && (
                  <select value={sort} onChange={(e) => setSort(e.target.value as SortKey)} aria-label="مرتب‌سازی">
                    <option value="updated_desc">جدیدترین تغییر</option>
                    <option value="created_desc">جدیدترین ساخت</option>
                    <option value="title_asc">الفبایی</option>
                    <option value="type_asc">نوع</option>
                  </select>
                )}
                {view === 'home' && status.itemCount > 6 && !query && (
                  <button type="button" className="btn btn-ghost sm" onClick={() => go('items')}>همه <Icon name="chevron" size={16} /></button>
                )}
                {view === 'trash' && status.trashCount > 0 && (
                  <button
                    type="button"
                    className="btn btn-ghost sm danger"
                    onClick={() =>
                      setConfirm({
                        title: 'خالی کردن سطل زباله',
                        body: `${fa(status.trashCount)} مورد و پیوست‌هایشان برای همیشه پاک می‌شوند.`,
                        confirmLabel: 'پاک کردن همه',
                        danger: true,
                        onConfirm: async () => {
                          try {
                            const n = await client.service.emptyTrash();
                            refresh(`${fa(n)} مورد برای همیشه حذف شد`);
                          } catch (e) {
                            toastError(errorText(e));
                          }
                        },
                      })
                    }
                  >
                    خالی کردن
                  </button>
                )}
              </div>
            </div>

            {list.length ? (
              <ul className="rows" key={`${view}-${typeFilter}-${sort}`}>
                {list.map((item, i) => (
                  <ItemRow key={item.id} index={i} item={item} showPreview={settings.showPreviews} onOpen={() => setEditor({ id: item.id })} />
                ))}
              </ul>
            ) : (
              <Empty view={view} searching={Boolean(query || typeFilter)} onCreate={() => newItem()} />
            )}
          </>
        )}

        <footer className="statusbar">
          <span><i className="dot" /> رمزنگاری فعال</span>
          <span>آفلاین · روی همین دستگاه</span>
        </footer>
      </main>

      {view !== 'settings' && (
        <button type="button" className="fab" aria-label="مورد جدید" onClick={() => newItem()}>
          <Icon name="plus" size={24} />
        </button>
      )}

      <nav className="tabbar" aria-label="ناوبری پایین">
        {nav.map((n) => (
          <button type="button" key={n.v} className={view === n.v ? 'tab on' : 'tab'} aria-current={view === n.v ? 'page' : undefined} onClick={() => go(n.v)}>
            <Icon name={n.icon} size={21} />
            <span>{n.label}</span>
          </button>
        ))}
      </nav>

      {editor && (
        <ItemEditor
          key={editor.id ?? 'new'}
          service={client.service}
          itemId={editor.id}
          initialType={editor.type}
          clipboardSeconds={settings.clipboardClearSeconds}
          onClose={() => setEditor(null)}
          onChanged={refresh}
          onError={toastError}
          onToast={(t) => toast(t, 'info')}
          confirm={(c) => setConfirm(c)}
        />
      )}
      {confirm && <ConfirmDialog state={confirm} onClose={() => setConfirm(null)} />}
      <Toasts items={toasts} onDismiss={(id) => setToasts((t) => t.filter((x) => x.id !== id))} />
    </div>
  );
}

createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
